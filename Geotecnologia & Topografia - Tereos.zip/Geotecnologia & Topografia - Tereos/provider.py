from qgis.core import (
    QgsProcessingProvider,
    QgsProcessingModelAlgorithm
)
from qgis.PyQt.QtGui import QIcon
import os

# Wrapper que adiciona suporte a ícone por modelo
class ModelAlgorithmWithIcon(QgsProcessingModelAlgorithm):
    def __init__(self, path, icon_path=None):
        super().__init__()
        self._path = path
        self._icon_path = icon_path
        self.fromFile(path)

    def icon(self):
        if self._icon_path and os.path.exists(self._icon_path):
            return QIcon(self._icon_path)
        return QIcon(os.path.join(os.path.dirname(__file__), "icons", "logo.png"))

class MeuProvider(QgsProcessingProvider):
    def loadAlgorithms(self):
        base_dir = os.path.join(os.path.dirname(__file__), "models")
        if os.path.exists(base_dir):
            for file in os.listdir(base_dir):
                if file.endswith(".model3"):
                    path_modelo = os.path.join(base_dir, file)
                    nome_base = os.path.splitext(file)[0]

                    # procura ícone correspondente
                    icon_path = None
                    for ext in [".png", ".svg", ".ico"]:
                        tentativa = os.path.join(os.path.dirname(__file__), "icons", nome_base + ext)
                        if os.path.exists(tentativa):
                            icon_path = tentativa
                            break

                    # adiciona algoritmo com wrapper
                    alg = ModelAlgorithmWithIcon(path_modelo, icon_path)
                    self.addAlgorithm(alg)

    def id(self):
        return "geotecnologia & topografia - tereos"

    def name(self):
        return "Geotecnologia & Topografia - Tereos"

    def icon(self):
        return QIcon(os.path.join(os.path.dirname(__file__), "icons", "logo.png"))
