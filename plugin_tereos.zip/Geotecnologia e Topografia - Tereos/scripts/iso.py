# -*- coding: utf-8 -*-
"""
Topcon: Extrair linhas de BIN (com parâmetros de performance e segmentação)
Converte arquivos .BIN em linhas (WGS84), procurando pares (lat,lon) em 1e-7 graus.
"""

import os
import struct

from qgis.PyQt.QtCore import QVariant
from qgis.core import (
    QgsFields, QgsField, QgsFeature, QgsGeometry, QgsPointXY,
    QgsWkbTypes, QgsRectangle, QgsCoordinateReferenceSystem,
    QgsProcessing, QgsProcessingAlgorithm, QgsProcessingException,
    QgsProcessingParameterFile, QgsProcessingParameterExtent,
    QgsProcessingParameterCrs, QgsProcessingParameterFeatureSink,
    QgsProcessingParameterNumber, QgsProcessingParameterEnum,
    QgsProcessingParameterBoolean
)


class TopconExtrairLinhasBIN(QgsProcessingAlgorithm):
    INPUT_DIR = 'INPUT_DIR'
    EXTENT = 'EXTENT'
    CRS = 'CRS'
    OUTPUT = 'OUTPUT'
    STEP = 'STEP'
    MINPTS = 'MINPTS'
    ENDIAN = 'ENDIAN'
    SPLIT = 'SPLIT'
    JUMP_THRESH = 'JUMP_THRESH'

    def initAlgorithm(self, config=None):
        # Pasta com os .BIN (procura recursivamente)
        self.addParameter(
            QgsProcessingParameterFile(
                self.INPUT_DIR,
                'Pasta raiz com arquivos .BIN',
                behavior=QgsProcessingParameterFile.Folder
            )
        )

        # Extent (filtro geográfico) em WGS84 (lon/lat) - Tanabi/SP como padrão
        self.addParameter(
            QgsProcessingParameterExtent(
                self.EXTENT,
                'Filtro geográfico (WGS84: xmin, ymin, xmax, ymax)',
                defaultValue='-49.7,-20.7,-49.5,-20.5'
            )
        )

        # CRS de saída
        self.addParameter(
            QgsProcessingParameterCrs(
                self.CRS,
                'CRS de saída',
                defaultValue='EPSG:4326'
            )
        )

        # Performance: passo em bytes ao varrer o arquivo
        self.addParameter(
            QgsProcessingParameterNumber(
                self.STEP,
                'Passo (bytes) ao ler o BIN',
                type=QgsProcessingParameterNumber.Integer,
                defaultValue=1,
                minValue=1
            )
        )

        # Mínimo de pontos para gravar uma linha
        self.addParameter(
            QgsProcessingParameterNumber(
                self.MINPTS,
                'Mínimo de pontos para criar linha',
                type=QgsProcessingParameterNumber.Integer,
                defaultValue=3,
                minValue=2
            )
        )

        # Endianess para o unpack
        self.addParameter(
            QgsProcessingParameterEnum(
                self.ENDIAN,
                'Endianess dos inteiros (lat, lon)',
                options=['Little-endian (<ii)', 'Big-endian (>ii)'],
                defaultValue=0  # Little
            )
        )

        # Segmentar por “salto” grande entre pontos?
        self.addParameter(
            QgsProcessingParameterBoolean(
                self.SPLIT,
                'Quebrar linha quando houver salto grande entre pontos',
                defaultValue=False
            )
        )

        # Limiar de salto (em graus). Aproximado e rápido.
        self.addParameter(
            QgsProcessingParameterNumber(
                self.JUMP_THRESH,
                'Limite de salto entre pontos (graus)',
                type=QgsProcessingParameterNumber.Double,
                defaultValue=0.0005,  # ~55 m na linha do equador (~cos(lat)*)
                minValue=0.0
            )
        )

        # Saída
        self.addParameter(
            QgsProcessingParameterFeatureSink(
                self.OUTPUT,
                'Linhas extraídas'
            )
        )

    def processAlgorithm(self, parameters, context, feedback):
        pasta = self.parameterAsFile(parameters, self.INPUT_DIR, context)
        if not pasta or not os.path.isdir(pasta):
            raise QgsProcessingException('Pasta inválida ou não informada.')

        extent_rect = self.parameterAsExtent(parameters, self.EXTENT, context)
        if not isinstance(extent_rect, QgsRectangle):
            raise QgsProcessingException('Extent inválido.')

        out_crs = self.parameterAsCrs(parameters, self.CRS, context)
        if not isinstance(out_crs, QgsCoordinateReferenceSystem) or not out_crs.isValid():
            out_crs = QgsCoordinateReferenceSystem('EPSG:4326')

        step = int(self.parameterAsInt(parameters, self.STEP, context))
        minpts = int(self.parameterAsInt(parameters, self.MINPTS, context))
        endian_choice = int(self.parameterAsEnum(parameters, self.ENDIAN, context))
        split_on_jump = bool(self.parameterAsBoolean(parameters, self.SPLIT, context))
        jump_thresh = float(self.parameterAsDouble(parameters, self.JUMP_THRESH, context))

        endian_fmt = '<ii' if endian_choice == 0 else '>ii'

        fields = QgsFields()
        fields.append(QgsField('Arquivo', QVariant.String))
        fields.append(QgsField('Subpasta', QVariant.String))

        sink, dest_id = self.parameterAsSink(
            parameters, self.OUTPUT, context,
            fields, QgsWkbTypes.LineString, out_crs
        )
        if sink is None:
            raise QgsProcessingException('Não foi possível criar a saída.')

        # Busca recursiva
        bin_files = []
        for root, _, files in os.walk(pasta):
            for f in files:
                if f.lower().endswith('.bin'):
                    bin_files.append(os.path.join(root, f))

        if not bin_files:
            feedback.pushWarning('Nenhum arquivo .BIN encontrado na pasta ou subpastas.')
            return {self.OUTPUT: dest_id}

        feedback.pushInfo(f'🔎 {len(bin_files)} arquivos .BIN encontrados.')
        total_linhas = 0
        cancel_check_interval = max(1, len(bin_files) // 50)

        for idx, bin_path in enumerate(bin_files, 1):
            if idx % cancel_check_interval == 0 and feedback.isCanceled():
                feedback.pushInfo('Processo cancelado pelo usuário.')
                break

            added = self._processar_um_bin(
                bin_path, pasta, extent_rect, sink, feedback,
                endian_fmt, step, minpts, split_on_jump, jump_thresh
            )
            total_linhas += added
            feedback.setProgress(int(100 * idx / len(bin_files)))

        feedback.pushInfo(f'✅ Linhas geradas: {total_linhas}')
        return {self.OUTPUT: dest_id}

    def _processar_um_bin(self, bin_path, pasta_base, extent_rect, sink, feedback,
                          endian_fmt, step, minpts, split_on_jump, jump_thresh):
        try:
            with open(bin_path, 'rb') as f:
                data = f.read()
        except Exception as e:
            feedback.pushWarning(f'Falha ao ler {bin_path}: {e}')
            return 0

        coords = []
        # Varrendo com passo configurável
        rng = range(0, len(data) - 8, step)
        for i in rng:
            try:
                lat_raw, lon_raw = struct.unpack(endian_fmt, data[i:i+8])
                lat = lat_raw / 1e7
                lon = lon_raw / 1e7
                if extent_rect.contains(QgsPointXY(lon, lat)):
                    coords.append((lat, lon))
            except Exception:
                continue

        if len(coords) < minpts:
            return 0

        # Segmentação opcional por “salto”
        segments = []
        if split_on_jump:
            current = [coords[0]]
            for a, b in zip(coords, coords[1:]):
                (lat1, lon1), (lat2, lon2) = a, b
                # salto simples em graus (barato). Se preferir precisão, dá pra usar distância projetada.
                if abs(lat2 - lat1) > jump_thresh or abs(lon2 - lon1) > jump_thresh:
                    if len(current) >= minpts:
                        segments.append(current)
                    current = [b]
                else:
                    current.append(b)
            if len(current) >= minpts:
                segments.append(current)
        else:
            segments = [coords]

        if not segments:
            return 0

        bf = os.path.basename(bin_path)
        subpasta = os.path.relpath(os.path.dirname(bin_path), pasta_base)

        added = 0
        for seg in segments:
            if len(seg) < minpts:
                continue
            pontos = [QgsPointXY(lon, lat) for (lat, lon) in seg]
            feat = QgsFeature()
            feat.setFields(sink.fields())
            feat['Arquivo'] = bf
            feat['Subpasta'] = subpasta
            feat.setGeometry(QgsGeometry.fromPolylineXY(pontos))
            ok, _ = sink.addFeature(feat)
            if ok:
                added += 1
            else:
                feedback.pushWarning(f'Não foi possível adicionar feição de {bf} (segmento).')

        return added

    def name(self):
        return 'topcon_extrair_linhas_bin'

    def displayName(self):
        return 'Topcon: Extrair linhas de BIN'

    def group(self):
        return 'Scripts personalizados'

    def groupId(self):
        return 'scripts_personalizados'

    def shortHelpString(self):
        return (
            "Converte arquivos .BIN em linhas, filtrando por um retângulo geográfico em WGS84.\n"
            "Parâmetros:\n"
            "• Pasta raiz com .BIN (procura em subpastas)\n"
            "• Extent WGS84 (xmin, ymin, xmax, ymax)\n"
            "• Passo (bytes) ao ler o BIN para performance\n"
            "• Mínimo de pontos para criar linha\n"
            "• Endianess (<ii ou >ii)\n"
            "• Quebrar linha por salto grande entre pontos (limiar em graus)\n"
            "Saída: camada de linhas com campos Arquivo e Subpasta."
        )

    def createInstance(self):
        return TopconExtrairLinhasBIN()
