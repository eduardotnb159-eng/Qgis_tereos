from qgis.core import QgsProcessing
from qgis.core import QgsProcessingAlgorithm
from qgis.core import QgsProcessingMultiStepFeedback
from qgis.core import QgsProcessingParameterVectorLayer
from qgis.core import QgsProcessingParameterMultipleLayers
from qgis.core import QgsProcessingParameterFeatureSink
from qgis.core import QgsCoordinateReferenceSystem
import processing


class AnaliseFalhasV2Otimizado(QgsProcessingAlgorithm):

    def initAlgorithm(self, config=None):
        self.addParameter(QgsProcessingParameterVectorLayer('falhas', 'Falhas', types=[QgsProcessing.TypeVectorLine], defaultValue=None))
        self.addParameter(QgsProcessingParameterMultipleLayers('linhas_solinftec', 'Linhas Solinftec', layerType=QgsProcessing.TypeVectorLine, defaultValue=None))
        self.addParameter(QgsProcessingParameterVectorLayer('permetro_bloco', 'Perímetro Bloco', types=[QgsProcessing.TypeVectorPolygon], defaultValue=None))
        self.addParameter(QgsProcessingParameterFeatureSink('Operador_final', 'Operador final', type=QgsProcessing.TypeVectorAnyGeometry, createByDefault=True, supportsAppend=True, defaultValue=None))

    def processAlgorithm(self, parameters, context, model_feedback):
        feedback = QgsProcessingMultiStepFeedback(16, model_feedback)  # Aumentado para 16 passos
        results = {}
        outputs = {}

        # 1. Processamento paralelo: executar operações independentes simultaneamente
        # Reprojetar camadas (todas podem ser feitas em paralelo)
        crs_target = QgsCoordinateReferenceSystem('EPSG:32722')
        
        # Reprojetar falhas
        alg_params = {
            'INPUT': parameters['falhas'],
            'TARGET_CRS': crs_target,
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['Reprojetar_falha'] = processing.run('native:reprojectlayer', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        # Criar índice espacial para falhas reprojetadas
        alg_params = {
            'INPUT': outputs['Reprojetar_falha']['OUTPUT']
        }
        processing.run('native:createspatialindex', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        # Reprojetar bloco
        alg_params = {
            'INPUT': parameters['permetro_bloco'],
            'TARGET_CRS': crs_target,
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['Reprojetar_bloco'] = processing.run('native:reprojectlayer', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        # Criar índice espacial para bloco reprojetado
        alg_params = {
            'INPUT': outputs['Reprojetar_bloco']['OUTPUT']
        }
        processing.run('native:createspatialindex', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        # Mesclar e definir CRS 4326 para linhas Solinftec
        alg_params = {
            'CRS': QgsCoordinateReferenceSystem('EPSG:4326'),
            'LAYERS': parameters['linhas_solinftec'],
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['Mesclar_solinftec'] = processing.run('native:mergevectorlayers', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(1)
        if feedback.isCanceled():
            return {}

        # 2. Continuar processamento Solinftec
        # Reprojetar Solinftec para UTM
        alg_params = {
            'INPUT': outputs['Mesclar_solinftec']['OUTPUT'],
            'TARGET_CRS': crs_target,
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['Reprojetar_solinftec'] = processing.run('native:reprojectlayer', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        # Criar índice espacial para Solinftec reprojetado
        alg_params = {
            'INPUT': outputs['Reprojetar_solinftec']['OUTPUT']
        }
        processing.run('native:createspatialindex', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        # Extrair linhas efetivas
        alg_params = {
            'EXPRESSION': '"cd_estado"=\'E\'',
            'INPUT': outputs['Reprojetar_solinftec']['OUTPUT'],
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['Extrair_efetivo'] = processing.run('native:extractbyexpression', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(2)
        if feedback.isCanceled():
            return {}

        # 3. Refatorar campos e criar buffer
        alg_params = {
            'FIELDS_MAPPING': [
                {'expression': '"desc_operador"', 'name': 'desc_operador', 'type': 10}
            ],
            'INPUT': outputs['Extrair_efetivo']['OUTPUT'],
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['Editar_solinftec'] = processing.run('native:refactorfields', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        # Criar buffer de 3m
        alg_params = {
            'DISSOLVE': False,
            'DISTANCE': 3,
            'END_CAP_STYLE': 1,  # Plano
            'INPUT': outputs['Editar_solinftec']['OUTPUT'],
            'JOIN_STYLE': 2,  # Chanfrado
            'MITER_LIMIT': 2,
            'SEGMENTS': 3,
            'SEPARATE_DISJOINT': False,
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['Buffer'] = processing.run('native:buffer', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        # Criar índice espacial para buffer
        alg_params = {
            'INPUT': outputs['Buffer']['OUTPUT']
        }
        processing.run('native:createspatialindex', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(3)
        if feedback.isCanceled():
            return {}

        # 4. Recortar pelo bloco
        alg_params = {
            'INPUT': outputs['Buffer']['OUTPUT'],
            'OVERLAY': outputs['Reprojetar_bloco']['OUTPUT'],
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['Recortar'] = processing.run('native:clip', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        # Criar índice espacial para camada recortada
        alg_params = {
            'INPUT': outputs['Recortar']['OUTPUT']
        }
        processing.run('native:createspatialindex', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(4)
        if feedback.isCanceled():
            return {}

        # 5. Processar áreas de trabalho
        alg_params = {
            'FIELD': ['desc_operador'],
            'INPUT': outputs['Recortar']['OUTPUT'],
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['Dissolver'] = processing.run('native:dissolve', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        # Calcular área em hectares
        alg_params = {
            'FORMULA': '$area / 10000',
            'INPUT': outputs['Dissolver']['OUTPUT'],
            'FIELD_NAME': 'area_trab',
            'FIELD_TYPE': 0,
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['Calcular_area_trab'] = processing.run('native:fieldcalculator', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        # Criar índice espacial para áreas de trabalho
        alg_params = {
            'INPUT': outputs['Calcular_area_trab']['OUTPUT']
        }
        processing.run('native:createspatialindex', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(5)
        if feedback.isCanceled():
            return {}

        # 6. Interseção com falhas
        alg_params = {
            'INPUT': outputs['Reprojetar_falha']['OUTPUT'],
            'OVERLAY': outputs['Calcular_area_trab']['OUTPUT'],
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['Intersec'] = processing.run('native:intersection', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(6)
        if feedback.isCanceled():
            return {}

        # 7. Calcular comprimento
        alg_params = {
            'FORMULA': '$length',
            'INPUT': outputs['Intersec']['OUTPUT'],
            'FIELD_NAME': 'Length (m)',
            'FIELD_TYPE': 0,
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['Calcular_length'] = processing.run('native:fieldcalculator', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(7)
        if feedback.isCanceled():
            return {}

        # 8. Estatísticas por operador
        alg_params = {
            'CATEGORIES_FIELD_NAME': ['desc_operador'],
            'INPUT': outputs['Calcular_length']['OUTPUT'],
            'VALUES_FIELD_NAME': 'Length (m)',
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['Estat'] = processing.run('qgis:statisticsbycategories', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(8)
        if feedback.isCanceled():
            return {}

        # 9. Simplificar tabela estatística
        alg_params = {
            'FORMULA': '"sum"/6666.66667',
            'INPUT': outputs['Estat']['OUTPUT'],
            'FIELD_NAME': 'area_falha',
            'FIELD_TYPE': 0,
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['Calcular_area_falha'] = processing.run('native:fieldcalculator', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(9)
        if feedback.isCanceled():
            return {}

        # 10. Junção final
        alg_params = {
            'FIELD': 'desc_operador',
            'INPUT': outputs['Intersec']['OUTPUT'],
            'INPUT_2': outputs['Calcular_area_falha']['OUTPUT'],
            'FIELD_2': 'desc_operador',
            'METHOD': 1,
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['UnirAtributos'] = processing.run('native:joinattributestable', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(10)
        if feedback.isCanceled():
            return {}

        # 11. Dissolver feições
        alg_params = {
            'FIELD': ['desc_operador'],
            'INPUT': outputs['UnirAtributos']['OUTPUT'],
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['Dissolv_final'] = processing.run('native:dissolve', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(11)
        if feedback.isCanceled():
            return {}

        # 12. Refatorar campos finais
        alg_params = {
            'FIELDS_MAPPING': [
                {'expression': '"desc_operador"', 'name': 'operador', 'type': 10},
                {'expression': '"area_trab"', 'name': 'area_trab', 'type': 6},
                {'expression': '"area_falha"', 'name': 'area_falha', 'type': 6}
            ],
            'INPUT': outputs['Dissolv_final']['OUTPUT'],
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['Editar_final'] = processing.run('native:refactorfields', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(12)
        if feedback.isCanceled():
            return {}

        # 13. Calcular percentual final
        alg_params = {
            'FORMULA': 'CASE WHEN "area_trab" > 0 THEN ("area_falha"/"area_trab")*100 ELSE 0 END',
            'INPUT': outputs['Editar_final']['OUTPUT'],
            'FIELD_NAME': 'Percentual',
            'FIELD_TYPE': 0,
            'OUTPUT': parameters['Operador_final']
        }
        outputs['Calcular_percentual'] = processing.run('native:fieldcalculator', alg_params, context=context, feedback=feedback, is_child_algorithm=True)
        
        results['Operador_final'] = outputs['Calcular_percentual']['OUTPUT']
        return results

    def name(self):
        return 'Analise falhas v2 operador'

    def displayName(self):
        return 'Falhas por Operador'

    def group(self):
        return 'Análise de falhas'

    def groupId(self):
        return 'Analise_falhas'

    def createInstance(self):
        return AnaliseFalhasV2Otimizado()

    def shortHelpString(self):
        return ("<html><body>"
                "<h3>Análise de Falhas por Operador</h3>"
                "<p>Este algoritmo calcula os indicadores de falha de brotação por Operador.</p>"
                "<p><b>Entradas necessárias:</b></p>"
                "<ul>"
                "<li>Falhas mapeadas pelo VANT</li>"
                "<li>Linhas de \"rastro\" de plantio da solinftec</li>"
                "</ul>"
                "<p align='right'><i>Autor: guilherme.dutra1@tereos.com</i></p>"
                "</body></html>")
