# -*- coding: utf-8 -*-
"""
Criar Linhas – COLHEDORA (±0,75 m) com reprojeção para EPSG:31982
Passos:
 1) Reprojetar para EPSG:31982
 2) Offset +0.75 m e -0.75 m
 3) Mesclar offsets
 4) Manter apenas BLOCO e PARTE
 5) Adicionar GLEBA (valor informado)
Saída: caminho escolhido (SHP ou GPKG)
"""

from qgis.PyQt.QtCore import QCoreApplication
from qgis.core import (
    QgsProcessing, QgsProcessingAlgorithm, QgsProcessingException,
    QgsProcessingParameterVectorLayer, QgsProcessingParameterString,
    QgsProcessingParameterVectorDestination, QgsWkbTypes, QgsCoordinateReferenceSystem
)
import processing

DIST = 0.75  # metros
TARGET_CRS = QgsCoordinateReferenceSystem("EPSG:31982")

def tr(s): return QCoreApplication.translate("Tereos", s)

def _find_name_case_insensitive(layer, target):
    t = target.lower()
    for f in layer.fields():
        if f.name().lower() == t:
            return f.name()
    return None

def _build_refactor_mapping(layer_after_merge, gleba_value):
    """
    Mantém somente BLOCO e PARTE (case-insensitive), e adiciona GLEBA (texto).
    Para native:refactorfields, 'type' = 10 corresponde a String.
    """
    name_bloco = _find_name_case_insensitive(layer_after_merge, "BLOCO")
    name_parte = _find_name_case_insensitive(layer_after_merge, "PARTE")
    gleba_escaped = (gleba_value or "").replace("'", "''")

    mapping = []
    # BLOCO
    mapping.append({
        "expression": f'"{name_bloco}"' if name_bloco else "''",
        "length": 255, "name": "BLOCO", "precision": 0, "type": 10
    })
    # PARTE
    mapping.append({
        "expression": f'"{name_parte}"' if name_parte else "''",
        "length": 255, "name": "PARTE", "precision": 0, "type": 10
    })
    # GLEBA (constante)
    mapping.append({
        "expression": f"'{gleba_escaped}'",
        "length": 255, "name": "GLEBA", "precision": 0, "type": 10
    })
    return mapping


class CriarLinhasColhedora31982(QgsProcessingAlgorithm):
    P_INPUT = "INPUT"
    P_GLEBA = "GLEBA"
    P_OUT = "OUTPUT"

    def name(self): return "criar_linhas_colhedora_31982"
    def displayName(self): return tr("Criar Linhas – COLHEDORA")
    def group(self): return tr("Projetos de Linhas")
    def groupId(self): return "projeto_de_linhas"
    def createInstance(self): return CriarLinhasColhedora31982()

    def shortHelpString(self):
        return tr(
            "Reprojeta para EPSG:31982, gera offsets +0,75 m e −0,75 m, "
            "mescla, mantém só BLOCO e PARTE e adiciona GLEBA."
        )

    def initAlgorithm(self, config=None):
        self.addParameter(QgsProcessingParameterVectorLayer(
            self.P_INPUT, tr("Camada de linhas (com BLOCO e PARTE)"),
            [QgsProcessing.TypeVectorLine]
        ))
        self.addParameter(QgsProcessingParameterString(
            self.P_GLEBA, tr("Valor para o campo GLEBA"), defaultValue=""
        ))
        self.addParameter(QgsProcessingParameterVectorDestination(
            self.P_OUT, tr("Saída (offsets mesclados)")
        ))

    def processAlgorithm(self, params, context, feedback):
        lyr_in = self.parameterAsVectorLayer(params, self.P_INPUT, context)
        gleba_value = self.parameterAsString(params, self.P_GLEBA, context)
        out_path = self.parameterAsOutputLayer(params, self.P_OUT, context)

        if not lyr_in or not lyr_in.isValid():
            raise QgsProcessingException(tr("Camada de entrada inválida."))
        if QgsWkbTypes.geometryType(lyr_in.wkbType()) != QgsWkbTypes.LineGeometry:
            raise QgsProcessingException(tr("A camada precisa ser de LINHA."))

        # 1) Reprojetar para EPSG:31982 (se já estiver, o QGIS ainda assim criará uma cópia coerente)
        feedback.pushInfo(tr("Reprojetando para EPSG:31982..."))
        reproj = processing.run(
            "native:reprojectlayer",
            {"INPUT": lyr_in, "TARGET_CRS": TARGET_CRS, "OUTPUT": "memory:"},
            context=context, feedback=feedback
        )["OUTPUT"]

        # 2) Offset +0.75 m
        feedback.pushInfo(tr("Gerando offset +0,75 m..."))
        pos = processing.run(
            "native:offsetline",
            {
                "INPUT": reproj, "DISTANCE": DIST, "SEGMENTS": 8,
                "JOIN_STYLE": 0, "MITER_LIMIT": 2.0, "END_CAP_STYLE": 0,
                "OUTPUT": "memory:"
            },
            context=context, feedback=feedback
        )["OUTPUT"]

        # 3) Offset −0.75 m
        feedback.pushInfo(tr("Gerando offset −0,75 m..."))
        neg = processing.run(
            "native:offsetline",
            {
                "INPUT": reproj, "DISTANCE": -DIST, "SEGMENTS": 8,
                "JOIN_STYLE": 0, "MITER_LIMIT": 2.0, "END_CAP_STYLE": 0,
                "OUTPUT": "memory:"
            },
            context=context, feedback=feedback
        )["OUTPUT"]

        # 4) Mesclar
        feedback.pushInfo(tr("Mesclando offsets..."))
        merged = processing.run(
            "native:mergevectorlayers",
            {"LAYERS": [pos, neg], "CRS": TARGET_CRS, "OUTPUT": "memory:"},
            context=context, feedback=feedback
        )["OUTPUT"]

        # 5) Refatorar campos: BLOCO, PARTE + GLEBA
        feedback.pushInfo(tr("Refatorando campos (BLOCO, PARTE, GLEBA)..."))
        mapping = _build_refactor_mapping(merged, gleba_value)
        final = processing.run(
            "native:refactorfields",
            {"INPUT": merged, "FIELDS_MAPPING": mapping, "OUTPUT": out_path},
            context=context, feedback=feedback
        )["OUTPUT"]

        feedback.pushInfo(tr("Concluído: offsets ±0,75 m em EPSG:31982."))
        return {self.P_OUT: final}

def classFactory():
    return CriarLinhasColhedora31982()
