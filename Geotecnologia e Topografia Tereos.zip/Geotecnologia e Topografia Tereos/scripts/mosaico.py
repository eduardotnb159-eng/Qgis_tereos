from PyQt5.QtCore import QCoreApplication
from qgis.core import (QgsProcessing,
                       QgsProcessingAlgorithm,
                       QgsProcessingParameterMultipleLayers,
                       QgsProcessingParameterRasterDestination,
                       QgsProcessingParameterNumber,
                       QgsProcessingParameterEnum)
import processing
import os

class MosaicoImagens(QgsProcessingAlgorithm):

    # Constantes para parâmetros
    INPUT_LAYERS = 'INPUT_LAYERS'
    OUTPUT = 'OUTPUT'
    DATA_TYPE = 'DATA_TYPE'
    NODATA_VALUE = 'NODATA_VALUE'

    def initAlgorithm(self, config=None):
        # Parâmetro de entrada: múltiplas camadas raster
        self.addParameter(
            QgsProcessingParameterMultipleLayers(
                self.INPUT_LAYERS,
                self.tr('Selecionar imagens para mosaico'),
                QgsProcessing.TypeRaster
            )
        )

        # Parâmetro para valor NoData
        self.addParameter(
            QgsProcessingParameterNumber(
                self.NODATA_VALUE,
                self.tr('Valor NoData'),
                type=QgsProcessingParameterNumber.Integer,
                defaultValue=0,
                optional=False
            )
        )

        # Parâmetro para tipo de dados
        data_types = ['Byte', 'UInt16', 'Int16', 'UInt32', 'Int32', 'Float32', 'Float64']
        self.addParameter(
            QgsProcessingParameterEnum(
                self.DATA_TYPE,
                self.tr('Tipo de dados de saída'),
                options=data_types,
                defaultValue=1  # UInt16
            )
        )

        # Parâmetro de saída
        self.addParameter(
            QgsProcessingParameterRasterDestination(
                self.OUTPUT,
                self.tr('Mosaico de saída')
            )
        )

    def processAlgorithm(self, parameters, context, feedback):
        # Obter os parâmetros
        input_layers = self.parameterAsLayerList(parameters, self.INPUT_LAYERS, context)
        nodata_value = self.parameterAsInt(parameters, self.NODATA_VALUE, context)
        data_type_index = self.parameterAsInt(parameters, self.DATA_TYPE, context)
        output_path = self.parameterAsOutputLayer(parameters, self.OUTPUT, context)

        # Verificar se há camadas selecionadas
        if not input_layers:
            raise QgsProcessingException(self.invalidSourceError(parameters, self.INPUT_LAYERS))

        # Mapear índice para tipo de dados GDAL
        data_types_gdal = [1, 2, 3, 4, 5, 6, 7]  # Correspondente aos tipos do GDAL
        data_type = data_types_gdal[data_type_index]

        # Obter caminhos dos arquivos das camadas
        input_files = []
        for layer in input_layers:
            if layer.source():
                input_files.append(layer.source())
            else:
                feedback.pushWarning(f"Camada {layer.name()} não possui fonte de arquivo válida")

        if not input_files:
            raise QgsProcessingException("Nenhuma camada com fonte de arquivo válida encontrada")

        feedback.pushInfo(f"Processando {len(input_files)} imagens para mosaico...")

        # Executar o mosaico
        processing.run("gdal:merge", {
            'INPUT': input_files,
            'SEPARATE': False,
            'NODATA_INPUT': nodata_value,
            'NODATA_OUTPUT': nodata_value,
            'OPTIONS': '',
            'DATA_TYPE': data_type,
            'OUTPUT': output_path
        })

        feedback.pushInfo("✅ Mosaico criado com sucesso!")

        return {self.OUTPUT: output_path}

    def name(self):
        return 'mosaicoimagens'

    def displayName(self):
        return self.tr('Criar Mosaico de Imagens')

    def group(self):
        return self.tr('Raster')

    def groupId(self):
        return 'raster'

    def tr(self, string):
        return QCoreApplication.translate('Processing', string)

    def createInstance(self):
        return MosaicoImagens()

    def shortHelpString(self):
        return self.tr("""<html><body><p><!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0//EN" "http://www.w3.org/TR/REC-html40/strict.dtd">
<html><head><meta name="qrichtext" content="1" /><style type="text/css">
</style></head><body style=" font-family:'MS Shell Dlg 2'; font-size:7.8pt; font-weight:400; font-style:normal;">
<p style=" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;"><span style=" font-size:10pt;">Este algoritmo cria um mosaico de imagens.<br /></span><br /></p></body></html></p>
<br><p align="right">Autor do algoritmo: guilherme.dutra1@tereos.com</p></body></html>""")
