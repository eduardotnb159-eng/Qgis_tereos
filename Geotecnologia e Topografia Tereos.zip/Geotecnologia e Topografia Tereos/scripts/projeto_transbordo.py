# -*- coding: utf-8 -*-
"""
Criar Linhas – TRANSBORDO (a partir da COLHEDORA)
Lógica:
 1) Reprojetar entrada para EPSG:31982
 2) Offset único de +0.75 m (a partir das linhas da COLHEDORA)
 3) Manter apenas BLOCO e PARTE
 4) Adicionar GLEBA (valor informado)
Saída: caminho escolhido (SHP ou GPKG)

Se precisar em centímetros (0,75 cm), altere DIST = 0.0075
"""

from qgis.PyQt.QtCore import QCoreApplication
from qgis.core import (
    QgsProcessing, QgsProcessingAlgorithm, QgsProcessingException,
    QgsProcessingParameterVectorLayer, QgsProcessingParameterString,
    QgsProcessingParameterVectorDestination, QgsWkbTypes, QgsCoordinateReferenceSystem
)
import processing

DIST = 0.75  # metros (offset único); troque para 0.0075 se for 0,75 cm
TARGET_CRS = QgsCoordinateReferenceSystem("EPSG:31982")

def tr(s): return QCoreApplication.translate("Tereos", s)

def _find_name_case_insensitive(layer, target):
    t = target.lower()
    for f in layer.fields():
        if f.name().lower() == t:
            return f.name()
    return None

def _build_refactor_mapping(layer_after_offset, gleba_value):
    """Mantém BLOCO e PARTE (case-insensitive) e adiciona GLEBA (texto)."""
    name_bloco = _find_name_case_insensitive(layer_after_offset, "BLOCO")
    name_parte = _find_name_case_insensitive(layer_after_offset, "PARTE")
    gleba_escaped = (gleba_value or "").replace("'", "''")
    mapping = [
        {"expression": f'"{name_bloco}"' if name_bloco else "''",
         "length": 255, "name": "BLOCO", "precision": 0, "type": 10},
        {"expression": f'"{name_parte}"' if name_parte else "''",
         "length": 255, "name": "PARTE", "precision": 0, "type": 10},
        {"expression": f"'{gleba_escaped}'",
         "length": 255, "name": "GLEBA", "precision": 0, "type": 10},
    ]
    return mapping


class CriarLinhasTransbordoDeColhedora31982(QgsProcessingAlgorithm):
    P_INPUT = "INPUT"
    P_GLEBA = "GLEBA"
    P_OUT = "OUTPUT"

    def name(self): return "criar_linhas_transbordo_de_colhedora_31982"
    def displayName(self): return tr("Criar Linhas – TRANSBORDO")
    def group(self): return tr("Projetos de Linhas")
    def groupId(self): return "projeto_de_linhas"
    def createInstance(self): return CriarLinhasTransbordoDeColhedora31982()

    def shortHelpString(self):
        return tr("Usa as linhas da COLHEDORA como entrada, reprojeta para EPSG:31982, "
                  "gera um offset de +0,75 m, mantém BLOCO/PARTE e adiciona GLEBA.")

    def initAlgorithm(self, config=None):
        self.addParameter(QgsProcessingParameterVectorLayer(
            self.P_INPUT, tr("Camada de linhas da COLHEDORA (com BLOCO e PARTE)"),
            [QgsProcessing.TypeVectorLine]
        ))
        self.addParameter(QgsProcessingParameterString(
            self.P_GLEBA, tr("Valor para o campo GLEBA"), defaultValue=""
        ))
        self.addParameter(QgsProcessingParameterVectorDestination(
            self.P_OUT, tr("Saída (linhas TRANSBORDO)")
        ))

    def processAlgorithm(self, params, context, feedback):
        lyr_in = self.parameterAsVectorLayer(params, self.P_INPUT, context)
        gleba_value = self.parameterAsString(params, self.P_GLEBA, context)
        out_path = self.parameterAsOutputLayer(params, self.P_OUT, context)

        if not lyr_in or not lyr_in.isValid():
            raise QgsProcessingException(tr("Camada de entrada inválida."))
        if QgsWkbTypes.geometryType(lyr_in.wkbType()) != QgsWkbTypes.LineGeometry:
            raise QgsProcessingException(tr("A camada precisa ser de LINHA."))

        # 1) Reprojetar para EPSG:31982
        feedback.pushInfo(tr("Reprojetando para EPSG:31982..."))
        reproj = processing.run(
            "native:reprojectlayer",
            {"INPUT": lyr_in, "TARGET_CRS": TARGET_CRS, "OUTPUT": "memory:"},
            context=context, feedback=feedback
        )["OUTPUT"]

        # 2) Offset único (+DIST)
        feedback.pushInfo(tr(f"Gerando offset +{DIST} m..."))
        off = processing.run(
            "native:offsetline",
            {
                "INPUT": reproj,
                "DISTANCE": DIST,
                "SEGMENTS": 8,
                "JOIN_STYLE": 0,    # Round
                "MITER_LIMIT": 2.0,
                "END_CAP_STYLE": 0, # Round
                "OUTPUT": "memory:"
            },
            context=context, feedback=feedback
        )["OUTPUT"]

        # 3) Refatorar campos (BLOCO, PARTE, GLEBA)
        feedback.pushInfo(tr("Refatorando campos (BLOCO, PARTE, GLEBA)..."))
        mapping = _build_refactor_mapping(off, gleba_value)
        final = processing.run(
            "native:refactorfields",
            {"INPUT": off, "FIELDS_MAPPING": mapping, "OUTPUT": out_path},
            context=context, feedback=feedback
        )["OUTPUT"]

        feedback.pushInfo(tr("Concluído: linhas de TRANSBORDO geradas."))
        return {self.P_OUT: final}

def classFactory():
    return CriarLinhasTransbordoDeColhedora31982()
