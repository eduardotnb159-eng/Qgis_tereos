# -*- coding: utf-8 -*-
"""
Algoritmo único: Calcular Declividades - Geral
- Faz Zonal Statistics de declividade por talhão
- Exporta para Excel
- Cria tabela em memória no QGIS
- (se preciso) grava campo 'Declividade_media' na camada
- Reclassifica o raster em 0..5 e aplica a paleta de cores (estilo baseado no QML enviado)
"""

import os
import pandas as pd

from qgis.core import (
    QgsProcessing,
    QgsProcessingAlgorithm,
    QgsProcessingParameterVectorLayer,
    QgsProcessingParameterRasterLayer,
    QgsProcessingParameterNumber,
    QgsProcessingParameterField,
    QgsProcessingParameterBoolean,
    QgsProcessingParameterFileDestination,
    QgsProcessingParameterRasterDestination,
    QgsProcessingException,
    QgsField,
    QgsVectorLayer,
    QgsFeature,
    QgsProject,
    QgsColorRampShader,
    QgsRasterShader,
    QgsSingleBandPseudoColorRenderer,
    QgsRasterLayer
)
from qgis.PyQt.QtCore import QVariant
from qgis.PyQt.QtGui import QColor
import processing


class CalcularDeclividadesGeral(QgsProcessingAlgorithm):
    # parâmetros
    P_INPUT = "INPUT"
    P_RASTER = "RASTER"
    P_BAND = "BAND"
    P_ID_FIELD = "ID_FIELD"
    P_CREATE_FIELD = "CREATE_FIELD"
    P_OUT_XLSX = "OUT_XLSX"
    P_OUT_RECLASS = "OUT_RECLASS"

    def tr(self, text):
        return text

    def createInstance(self):
        return CalcularDeclividadesGeral()

    def name(self):
        # id interno
        return "calcular_declividades_geral"

    def displayName(self):
        # nome que aparece no Processing
        return self.tr("Calcular Declividades - Geral")

    def group(self):
        # grupo que você pediu
        return self.tr("Topografia (VANT)")

    def groupId(self):
        return "topografia_vant"

    def shortHelpString(self):
        return self.tr(
            "Executa o cálculo de declividade média por talhão (zonal + Excel + tabela em memória) "
            "e também reclassifica o raster de declividade em 6 classes (0..5) com cores padrão "
            "baseadas no estilo QML fornecido."
        )

    def initAlgorithm(self, config=None):
        # camada vetorial
        self.addParameter(
            QgsProcessingParameterVectorLayer(
                self.P_INPUT,
                self.tr("Camada de talhões/blocos (polígonos)"),
                [QgsProcessing.TypeVectorPolygon]
            )
        )

        # raster de declividade
        self.addParameter(
            QgsProcessingParameterRasterLayer(
                self.P_RASTER,
                self.tr("Raster de declividade (.tif)")
            )
        )

        # banda
        self.addParameter(
            QgsProcessingParameterNumber(
                self.P_BAND,
                self.tr("Banda do raster"),
                type=QgsProcessingParameterNumber.Integer,
                defaultValue=1,
                minValue=1
            )
        )

        # campo identificador opcional
        self.addParameter(
            QgsProcessingParameterField(
                self.P_ID_FIELD,
                self.tr("Campo identificador do talhão (opcional)"),
                parentLayerParameterName=self.P_INPUT,
                allowMultiple=False,
                optional=True
            )
        )

        # criar campo se não tiver
        self.addParameter(
            QgsProcessingParameterBoolean(
                self.P_CREATE_FIELD,
                self.tr("Se não houver campo, criar 'Declividade_media' na camada"),
                defaultValue=True
            )
        )

        # saída excel
        self.addParameter(
            QgsProcessingParameterFileDestination(
                self.P_OUT_XLSX,
                self.tr("Arquivo Excel de saída"),
                fileFilter="Arquivos Excel (*.xlsx)"
            )
        )

        # saída raster reclassificado
        self.addParameter(
            QgsProcessingParameterRasterDestination(
                self.P_OUT_RECLASS,
                self.tr("Raster reclassificado (0..5)")
            )
        )

    def processAlgorithm(self, parameters, context, feedback):
        # pegar parâmetros
        camada_in = self.parameterAsVectorLayer(parameters, self.P_INPUT, context)
        raster_in = self.parameterAsRasterLayer(parameters, self.P_RASTER, context)
        band = self.parameterAsInt(parameters, self.P_BAND, context)
        campo_id = self.parameterAsString(parameters, self.P_ID_FIELD, context)
        criar_campo = self.parameterAsBool(parameters, self.P_CREATE_FIELD, context)
        out_xlsx = self.parameterAsFileOutput(parameters, self.P_OUT_XLSX, context)
        out_reclass_path = self.parameterAsOutputLayer(parameters, self.P_OUT_RECLASS, context)

        if not camada_in or not camada_in.isValid():
            raise QgsProcessingException("Camada de entrada inválida.")
        if not raster_in or not raster_in.isValid():
            raise QgsProcessingException("Raster de declividade inválido.")

        # ============================
        # 1) ZONAL STATISTICS
        # ============================
        prefixo = "decliv_"
        campo_media = f"{prefixo}mean"

        feedback.pushInfo("🧮 Executando Zonal Statistics (fast)...")
        zonal_result = processing.run(
            "native:zonalstatisticsfb",
            {
                'INPUT': camada_in,
                'INPUT_RASTER': raster_in,
                'RASTER_BAND': band,
                'COLUMN_PREFIX': prefixo,
                'STATISTICS': [2],  # média
                'OUTPUT': 'memory:'
            },
            context=context,
            feedback=feedback
        )

        camada_zonal = zonal_result['OUTPUT']
        if not camada_zonal or not camada_zonal.isValid():
            raise QgsProcessingException("Falha ao executar Zonal Statistics.")

        # ============================
        # 2) MONTAR DADOS E EXCEL
        # ============================
        dados = []
        for feat in camada_zonal.getFeatures():
            media = feat[campo_media]
            media_arred = round(media, 2) if media is not None else None
            bloco_id = feat[campo_id] if campo_id else None
            dados.append({
                'Bloco': bloco_id,
                'Declividade_Média': media_arred
            })

        df = pd.DataFrame(dados)
        pasta_out = os.path.dirname(out_xlsx)
        if pasta_out and not os.path.exists(pasta_out):
            os.makedirs(pasta_out)
        df.to_excel(out_xlsx, index=False)
        feedback.pushInfo(f"✅ Planilha gerada em: {out_xlsx}")

        # ============================
        # 3) ATUALIZAR CAMADA ORIGINAL SE NÃO TIVER CAMPO
        # ============================
        if not campo_id and criar_campo:
            prov = camada_in.dataProvider()
            if 'Declividade_media' not in [f.name() for f in camada_in.fields()]:
                prov.addAttributes([QgsField('Declividade_media', QVariant.Double)])
                camada_in.updateFields()

            idx_decl = camada_in.fields().indexFromName('Declividade_media')
            # montar dicionário id -> média
            medias_por_id = {f.id(): f[campo_media] for f in camada_zonal.getFeatures()}

            camada_in.startEditing()
            for feat in camada_in.getFeatures():
                media = medias_por_id.get(feat.id(), None)
                camada_in.changeAttributeValue(
                    feat.id(),
                    idx_decl,
                    float(media) if media is not None else None
                )
            camada_in.commitChanges()

        # ============================
        # 4) CRIAR TABELA EM MEMÓRIA
        # ============================
        feedback.pushInfo("📥 Criando tabela em memória no QGIS...")
        tbl = QgsVectorLayer("None", "Declividade_Talhoes", "memory")
        prov_tbl = tbl.dataProvider()
        prov_tbl.addAttributes([
            QgsField("Bloco", QVariant.String),
            QgsField("Declividade_Media", QVariant.Double)
        ])
        tbl.updateFields()

        feats = []
        for row in dados:
            f = QgsFeature(tbl.fields())
            f.setAttribute("Bloco", row["Bloco"])
            f.setAttribute("Declividade_Media", row["Declividade_Média"])
            feats.append(f)

        prov_tbl.addFeatures(feats)
        tbl.updateExtents()
        QgsProject.instance().addMapLayer(tbl)
        feedback.pushInfo("📌 Tabela 'Declividade_Talhoes' adicionada ao QGIS.")

        # ============================
        # 5) RECLASSIFICAR RASTER + SIMBOLOGIA
        # ============================
        feedback.pushInfo("🗺️ Reclassificando raster de declividade...")

        # Tabela de reclassificação -> saída 0..5
        # 0 = NODATA (definido no NO_DATA)
        reclass_table = [
            -9999, 0, 0,
            0, 3, 1,
            3, 5, 2,
            5, 7, 3,
            7, 12, 4,
            12, 9999, 5
        ]

        recl = processing.run(
            "native:reclassifybytable",
            {
                'INPUT_RASTER': raster_in,
                'RASTER_BAND': band,
                'TABLE': reclass_table,
                'NO_DATA': 0,
                'RANGE_BOUNDARIES': 0,   # min <= v < max
                'DATA_TYPE': 2,          # UInt16
                'OUTPUT': out_reclass_path
            },
            context=context,
            feedback=feedback
        )

        reclass_path = recl['OUTPUT']

        # carregar para aplicar estilo
        out_layer = QgsRasterLayer(reclass_path, "Declividade_reclass", "gdal")
        if out_layer.isValid():
            feedback.pushInfo("Aplicando simbologia (estilo baseado no QML)...")

            # Shader de cores em modo DISCRETE, mínimo 1 e máximo 5 (como no QML)
            color_shader = QgsColorRampShader()
            color_shader.setColorRampType(QgsColorRampShader.Discrete)
            color_shader.setMinimumValue(1)
            color_shader.setMaximumValue(5)

            # Mapeamento das classes reclassificadas (1..5) para os rótulos/cores do QML:
            #  1 -> <= 2     (#11ff00)
            #  2 -> 2 - 3   (#28ab00)
            #  3 -> 3 - 3   (#ffc507)
            #  4 -> 3 - 4   (#ff5900)
            #  5 -> > 4     (#ff0004)
            items = [
                QgsColorRampShader.ColorRampItem(1, QColor("#11ff00"), "<= 2"),
                QgsColorRampShader.ColorRampItem(2, QColor("#28ab00"), "2 - 3"),
                QgsColorRampShader.ColorRampItem(3, QColor("#ffc507"), "3 - 3"),
                QgsColorRampShader.ColorRampItem(4, QColor("#ff5900"), "3 - 4"),
                QgsColorRampShader.ColorRampItem(5, QColor("#ff0004"), "> 4"),
            ]
            color_shader.setColorRampItemList(items)

            raster_shader = QgsRasterShader()
            raster_shader.setRasterShaderFunction(color_shader)

            renderer = QgsSingleBandPseudoColorRenderer(
                out_layer.dataProvider(),
                1,
                raster_shader
            )
            out_layer.setRenderer(renderer)
            out_layer.triggerRepaint()

            QgsProject.instance().addMapLayer(out_layer)
            feedback.pushInfo("✅ Raster reclassificado adicionado ao QGIS com estilo do QML.")
        else:
            feedback.reportError("Raster reclassificado foi gerado, mas não pôde ser carregado.")

        # ============================
        # 6) RETORNO
        # ============================
        return {
            self.P_OUT_XLSX: out_xlsx,
            self.P_OUT_RECLASS: reclass_path
        }
