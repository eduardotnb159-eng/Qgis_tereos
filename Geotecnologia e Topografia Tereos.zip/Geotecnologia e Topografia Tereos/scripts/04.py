# -*- coding: utf-8 -*-
"""
Model exported as python.
Name : Gerar Linhas escoamento (M. Chuva)
Group : Topografia (VANT)
With QGIS : 33410
"""

from qgis.PyQt.QtGui import QColor

from qgis.core import (
    QgsProcessing,
    QgsProcessingAlgorithm,
    QgsProcessingMultiStepFeedback,
    QgsProcessingParameterRasterLayer,
    QgsProcessingParameterVectorLayer,
    QgsProcessingParameterVectorDestination,
    QgsCoordinateReferenceSystem,
    QgsSymbol,
    QgsRendererCategory,
    QgsCategorizedSymbolRenderer,
    QgsWkbTypes,
    QgsProcessingUtils,
)

import processing


class GerarLinhasEscoamentoMChuva(QgsProcessingAlgorithm):

    # vamos guardar o id/destino da camada de saída para usar no postProcessAlgorithm
    dest_id = None

    def initAlgorithm(self, config=None):
        self.addParameter(
            QgsProcessingParameterRasterLayer(
                'camada_do_mdt',
                'Camada do MDT',
                defaultValue=None
            )
        )
        self.addParameter(
            QgsProcessingParameterVectorLayer(
                'rea_de_interesse',
                'Área de Interesse',
                types=[QgsProcessing.TypeVectorPolygon],
                defaultValue=None
            )
        )
        self.addParameter(
            QgsProcessingParameterVectorDestination(
                'Escoamento',
                'Escoamento',
                type=QgsProcessing.TypeVectorLine,
                createByDefault=True,
                defaultValue=None
            )
        )

    def processAlgorithm(self, parameters, context, model_feedback):
        feedback = QgsProcessingMultiStepFeedback(4, model_feedback)
        results = {}
        outputs = {}

        # 0 - Reprojetar camada
        alg_params = {
            'CONVERT_CURVED_GEOMETRIES': False,
            'INPUT': parameters['rea_de_interesse'],
            'OPERATION': '',
            'TARGET_CRS': QgsCoordinateReferenceSystem('EPSG:31982'),
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['ReprojetarCamada'] = processing.run(
            'native:reprojectlayer',
            alg_params,
            context=context,
            feedback=feedback,
            is_child_algorithm=True
        )

        feedback.setCurrentStep(1)
        if feedback.isCanceled():
            return {}

        # 1 - Buffer no Perímetro
        alg_params = {
            'DISSOLVE': False,
            'DISTANCE': 50,
            'END_CAP_STYLE': 0,  # Arredondado
            'INPUT': outputs['ReprojetarCamada']['OUTPUT'],
            'JOIN_STYLE': 0,     # Arredondado
            'MITER_LIMIT': 2,
            'SEGMENTS': 5,
            'SEPARATE_DISJOINT': False,
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['BufferNoPerimetro'] = processing.run(
            'native:buffer',
            alg_params,
            context=context,
            feedback=feedback,
            is_child_algorithm=True
        )

        feedback.setCurrentStep(2)
        if feedback.isCanceled():
            return {}

        # 2 - Recortar MDT pela área de interesse
        alg_params = {
            'ALPHA_BAND': False,
            'CROP_TO_CUTLINE': True,
            'DATA_TYPE': 0,  # Tipo de dado da camada de entrada
            'EXTRA': '',
            'INPUT': parameters['camada_do_mdt'],
            'KEEP_RESOLUTION': False,
            'MASK': outputs['BufferNoPerimetro']['OUTPUT'],
            'MULTITHREADING': False,
            'NODATA': None,
            'OPTIONS': '',
            'SET_RESOLUTION': False,
            'SOURCE_CRS': None,
            'TARGET_CRS': QgsCoordinateReferenceSystem('EPSG:31982'),
            'TARGET_EXTENT': None,
            'X_RESOLUTION': None,
            'Y_RESOLUTION': None,
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['RasterParaOsPontosDoCad'] = processing.run(
            'gdal:cliprasterbymasklayer',
            alg_params,
            context=context,
            feedback=feedback,
            is_child_algorithm=True
        )

        feedback.setCurrentStep(3)
        if feedback.isCanceled():
            return {}

        # 3 - Channel network and drainage basins (SAGA)
        alg_params = {
            'DEM': outputs['RasterParaOsPontosDoCad']['OUTPUT'],
            'SUBBASINS': True,
            'THRESHOLD': 5,
            'BASINS': QgsProcessing.TEMPORARY_OUTPUT,
            'SEGMENTS': parameters['Escoamento']
        }
        outputs['ChannelNetworkAndDrainageBasins'] = processing.run(
            'sagang:channelnetworkanddrainagebasins',
            alg_params,
            context=context,
            feedback=feedback,
            is_child_algorithm=True
        )

        # Resultado principal
        results['Escoamento'] = outputs['ChannelNetworkAndDrainageBasins']['SEGMENTS']

        # guarda o id/destino para usar depois no postProcessAlgorithm
        self.dest_id = outputs['ChannelNetworkAndDrainageBasins']['SEGMENTS']

        return results

    def postProcessAlgorithm(self, context, feedback):
        """
        Roda DEPOIS que o algoritmo terminou e a camada de saída foi carregada.
        Aqui aplicamos o estilo equivalente ao Classificação_Chuva.qml.
        """
        if not self.dest_id:
            return {}

        # Recupera a camada a partir do id/destino
        layer = QgsProcessingUtils.mapLayerFromString(self.dest_id, context)
        if layer is None:
            return {}

        # Confere se o campo ORDER existe
        if layer.fields().indexFromName('ORDER') == -1:
            return {}

        categories = []

        def _make_cat(value_str, label, rgba_str, width_mm):
            r, g, b, a = [int(v) for v in rgba_str.split(',')]
            symbol = QgsSymbol.defaultSymbol(layer.geometryType())
            if symbol is None:
                symbol = QgsSymbol.defaultSymbol(QgsWkbTypes.LineGeometry)

            if symbol is not None and symbol.symbolLayerCount() > 0:
                sl = symbol.symbolLayer(0)
                sl.setColor(QColor(r, g, b, a))
                sl.setWidth(float(width_mm))

            # usamos sempre string, porque o campo ORDER geralmente vem como texto
            categories.append(
                QgsRendererCategory(value_str, symbol, label)
            )

        # Categorias exatamente como no Classificação_Chuva.qml
        _make_cat('1', 'Normal',            '5,88,255,255',    0.2)
        _make_cat('2', 'Médio',             '0,34,255,255',    0.35)
        _make_cat('5', 'Sem Classificação', '200,200,200,255', 0.26)
        _make_cat('4', 'Risco Erosão',      '255,101,29,255',  0.5)
        _make_cat('',  '',                  '121,231,180,255', 0.26)
        _make_cat('3', 'Ponto Atenção',     '255,0,0,255',     0.66)

        renderer = QgsCategorizedSymbolRenderer('ORDER', categories)
        if renderer is not None:
            layer.setRenderer(renderer)
            layer.triggerRepaint()

        return {}

    def name(self):
        return 'Gerar Linhas escoamento (M. Chuva)'

    def displayName(self):
        return 'Gerar Linhas escoamento (M. Chuva)'

    def group(self):
        return 'Topografia (VANT)'

    def groupId(self):
        return 'Topografia (VANT)'

    def createInstance(self):
        return GerarLinhasEscoamentoMChuva()
