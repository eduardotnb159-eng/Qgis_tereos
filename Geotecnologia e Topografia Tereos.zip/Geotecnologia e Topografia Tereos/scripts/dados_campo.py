# -*- coding: utf-8 -*-
"""
Algoritmo: Mesclar SHP por nome-base -> SHP
- Vasculha uma pasta de entrada
- Agrupa todos os .shp pelo nome do arquivo (ex.: Gesso.shp, Gesso_2.shp => grupo "Gesso")
- Normaliza esquema (união de campos, sem forçar nenhum específico)
- Reprojeta para o CRS da primeira camada do grupo (se necessário)
- Mescla e grava cada grupo em um SHP separado: <Saída>/<grupo>.shp
"""

import os
from pathlib import Path

from qgis.PyQt.QtCore import QCoreApplication
from qgis.core import (
    QgsVectorLayer,
    QgsVectorFileWriter,
    QgsCoordinateTransformContext,
    QgsProcessing,
    QgsProcessingAlgorithm,
    QgsProcessingParameterFile,
    QgsProcessingParameterFolderDestination,
    QgsProcessingException
)
import processing


class MergeShpByBasenameToShp(QgsProcessingAlgorithm):
    # Parâmetros
    P_IN_DIR = "IN_DIR"
    P_OUT_DIR = "OUT_DIR"

    def tr(self, string):
        return QCoreApplication.translate("MergeShpByBasenameToShp", string)

    def createInstance(self):
        return MergeShpByBasenameToShp()

    def name(self):
        return "merge_shp_by_basename_to_shp"

    def displayName(self):
        return self.tr("Mesclar SHP por nome-base → SHP")

    def group(self):
        return self.tr("Processamento de Dados")

    def groupId(self):
        return "processamento_de_dados"

    def shortHelpString(self):
        return self.tr(
            "Vasculha uma pasta por .shp, agrupa por nome-base do arquivo, "
            "normaliza campos (união), reprojeta para o CRS da primeira camada do grupo, "
            "mescla e salva cada grupo em um SHP (<grupo>.shp) com todas as feições."
        )

    def initAlgorithm(self, config=None):
        # Pasta de entrada (seleção de diretório)
        self.addParameter(
            QgsProcessingParameterFile(
                self.P_IN_DIR,
                self.tr("Pasta de entrada (contendo .shp)"),
                behavior=QgsProcessingParameterFile.Folder,  # abre seletor de pasta
                fileFilter=""
            )
        )

        # Pasta de saída (destino dos SHP)
        self.addParameter(
            QgsProcessingParameterFolderDestination(
                self.P_OUT_DIR,
                self.tr("Pasta de saída (serão criados arquivos .shp)")
            )
        )

    # ===== Helpers internas =====
    def _carregar(self, path):
        vl = QgsVectorLayer(path, os.path.basename(path), "ogr")
        return vl if vl.isValid() else None

    def _montar_canon(self, layers):
        """
        Esquema canônico = união de campos de todas as camadas.
        Não força campo algum (se 'Secoes' existir em alguma, entra naturalmente).
        """
        tipos, lens, precs = {}, {}, {}
        nomes, vistos = [], set()
        crs_canon = layers[0].crs()

        for vl in layers:
            for f in vl.fields():
                n = f.name()
                if n not in vistos:
                    nomes.append(n)
                    vistos.add(n)
                    tipos[n] = f.type()
                    lens[n] = f.length()
                    precs[n] = f.precision()

        return nomes, tipos, lens, precs, crs_canon

    def _refatorar(self, vl, nomes, tipos, lens, precs):
        mapeamento = []
        nomes_vl = [f.name() for f in vl.fields()]
        for n in nomes:
            expr = f'"{n}"' if n in nomes_vl else 'NULL'
            t, l, p = tipos[n], lens[n], precs[n]
            mapeamento.append(
                {"name": n, "type": t, "length": l, "precision": p, "expression": expr}
            )

        return processing.run(
            "native:refactorfields",
            {"INPUT": vl, "FIELDS_MAPPING": mapeamento, "OUTPUT": "memory:refatorada"},
        )["OUTPUT"]

    def _reprojetar(self, vl, crs_dest):
        if not vl.crs() or vl.crs() == crs_dest:
            return vl
        return processing.run(
            "native:reprojectlayer",
            {"INPUT": vl, "TARGET_CRS": crs_dest, "OUTPUT": "memory:reprojetada"},
        )["OUTPUT"]

    def _mesclar_para_memoria(self, layers):
        return processing.run(
            "native:mergevectorlayers",
            {"LAYERS": layers, "CRS": layers[0].crs(), "OUTPUT": "memory:merged"},
        )["OUTPUT"]

    def _salvar_shp(self, layer_mem, shp_path: Path):
        """
        Grava Shapefile (driver ESRI Shapefile).
        Observações:
        - Campo >10 chars será truncado pelo driver.
        - Encoding UTF-8: cria .cpg apropriado.
        """
        opts = QgsVectorFileWriter.SaveVectorOptions()
        opts.driverName = "ESRI Shapefile"
        opts.fileEncoding = "UTF-8"

        shp_path.parent.mkdir(parents=True, exist_ok=True)
        # Para shapefile, o "nome da camada" é derivado do nome do arquivo
        res, err = QgsVectorFileWriter.writeAsVectorFormatV3(
            layer_mem, str(shp_path), QgsCoordinateTransformContext(), opts
        )
        if res != QgsVectorFileWriter.NoError:
            raise QgsProcessingException(f"Falha ao gravar {shp_path.name}: {err}")

    # ===== Execução =====
    def processAlgorithm(self, parameters, context, feedback):
        in_dir = self.parameterAsFile(parameters, self.P_IN_DIR, context)
        out_dir = self.parameterAsFile(parameters, self.P_OUT_DIR, context)

        if not in_dir or not os.path.isdir(in_dir):
            raise QgsProcessingException(self.tr("Pasta de entrada inválida."))
        if not out_dir:
            raise QgsProcessingException(self.tr("Pasta de saída não definida."))

        feedback.pushInfo(f"📁 Entrada: {in_dir}")
        feedback.pushInfo(f"💾 Saída:   {out_dir}")

        # Encontrar e agrupar .shp por nome-base
        grupos = {}
        for root, _dirs, files in os.walk(in_dir):
            for f in files:
                if f.lower().endswith(".shp"):
                    nome_base = os.path.splitext(f)[0]
                    grupos.setdefault(nome_base, []).append(os.path.join(root, f))

        if not grupos:
            raise QgsProcessingException(self.tr("Nenhum .shp encontrado na pasta."))

        nomes_grupos = sorted(grupos.keys())
        feedback.pushInfo(f"🔎 Grupos: {', '.join(nomes_grupos)}")

        total = len(nomes_grupos)
        for i, nome_grupo in enumerate(nomes_grupos, start=1):
            if feedback.isCanceled():
                break

            caminhos = grupos[nome_grupo]
            feedback.pushInfo(f"\n=== 🧩 Grupo: {nome_grupo} | {len(caminhos)} arquivo(s) ===")

            # Carregar válidos
            vls = []
            for c in caminhos:
                vl = self._carregar(c)
                if vl is None:
                    feedback.reportError(f"   ❌ Inválido: {c}")
                else:
                    vls.append(vl)

            if not vls:
                feedback.pushInfo(f"   ⚠️ Sem camadas válidas para '{nome_grupo}'. Pulando.")
                feedback.setProgress(int(i * 100.0 / total))
                continue

            # Esquema canônico + CRS
            nomes, tipos, lens, precs, crs_canon = self._montar_canon(vls)

            # Refatorar + reprojetar
            normalizadas = []
            for vl in vls:
                if feedback.isCanceled():
                    break
                vl_ref = self._refatorar(vl, nomes, tipos, lens, precs)
                vl_rep = self._reprojetar(vl_ref, crs_canon)
                normalizadas.append(vl_rep)

            if feedback.isCanceled():
                break

            # Mesclar e salvar em SHP
            try:
                merged = self._mesclar_para_memoria(normalizadas)
                destino = Path(out_dir) / f"{nome_grupo}.shp"
                self._salvar_shp(merged, destino)
                feedback.pushInfo(f"   ✅ Mesclado e salvo: {destino}")
            except Exception as e:
                feedback.reportError(f"   ❌ Erro no grupo '{nome_grupo}': {e}")

            feedback.setProgress(int(i * 100.0 / total))

        feedback.pushInfo("\n🎉 Concluído!")
        # Sem saídas formais (gera múltiplos arquivos). Retorna dicionário vazio.
        return {}
