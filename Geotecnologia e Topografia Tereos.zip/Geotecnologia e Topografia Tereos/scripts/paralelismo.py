from qgis.PyQt.QtCore import QVariant, QCoreApplication
from qgis.core import (
    QgsProcessing,
    QgsProcessingAlgorithm,
    QgsProcessingParameterFeatureSource,
    QgsProcessingParameterFeatureSink,
    QgsFeature,
    QgsGeometry,
    QgsPointXY,
    QgsSpatialIndex,
    QgsField,
    QgsFields,
    QgsFeatureSink,
    QgsProcessingException,
    QgsWkbTypes,
    QgsFeatureRequest,
    QgsProcessingMultiStepFeedback,
    QgsProcessingParameterMultipleLayers,
    QgsCoordinateReferenceSystem,
    QgsVectorLayer,
    QgsProcessingParameterField
)
import processing

class ConnectNearestPointsCombined(QgsProcessingAlgorithm):
    INPUT_LINHAS = 'INPUT_LINHAS'
    INPUT_POLYGONS = 'INPUT_POLYGONS'
    OUTPUT_LINES = 'OUTPUT_LINES'
    OUTPUT_STATS = 'OUTPUT_STATS'

    def tr(self, string):
        return QCoreApplication.translate('Processing', string)

    def createInstance(self):
        return ConnectNearestPointsCombined()

    def name(self):
        return 'CalculoEspacamentoCompletov4'

    def displayName(self):
        return self.tr('Aderência ao Paralelismo')

    def group(self):
        return self.tr('Análise de Falhas')

    def groupId(self):
        return 'Analise_falhas'

    def shortHelpString(self):
        return self.tr("""<html><body><p><!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0//EN" "http://www.w3.org/TR/REC-html40/strict.dtd">
<html><head><meta name="qrichtext" content="1" /><style type="text/css">
</style></head><body style=" font-family:'MS Shell Dlg 2'; font-size:7.8pt; font-weight:400; font-style:normal;">
<p style=" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;"><span style=" font-size:10pt;">Este algoritmo utiliza as linhas restituídas do VANT para calcular o espaçamento entre linhas.<br /><br />São gerados valores de Aderência ao Paralelismo (%) e Risco de Amassamento (%).<br /><br />Para Aderência ao Paralelismo, é utilizado espaçamento entre 1.4 e 1.6 metros.<br />Para Risco de Amassamento, é utilizado espaçamento entre 1.35 e 1.65 metros.<br /></span><br /></p></body></html></p>
<br><p align="right">Autor do algoritmo: guilherme.dutra1@tereos.com</p></body></html>""")

    def initAlgorithm(self, config=None):
        # Parâmetros do primeiro script
        self.addParameter(
            QgsProcessingParameterMultipleLayers(
                self.INPUT_LINHAS,
                self.tr('Linhas restituídas'),
                layerType=QgsProcessing.TypeVectorLine,
                defaultValue=None
            )
        )
        
        # Parâmetro do segundo script (camada de polígonos com KEY)
        self.addParameter(
            QgsProcessingParameterFeatureSource(
                self.INPUT_POLYGONS,
                'Camada de Polígonos (com campo "KEY")',
                [QgsProcessing.TypeVectorPolygon],
                optional=True  # Torna opcional para manter compatibilidade
            )
        )
        
        # Saída do primeiro script
        self.addParameter(
            QgsProcessingParameterFeatureSink(
                self.OUTPUT_LINES,
                self.tr('Linhas de espaçamento'),
                type=QgsProcessing.TypeVectorLine,
                createByDefault=True,
                supportsAppend=True,
                defaultValue=None
            )
        )
        
        # Saída do segundo script (estatísticas)
        self.addParameter(
            QgsProcessingParameterFeatureSink(
                self.OUTPUT_STATS,
                'Resultados aderência',
                type=QgsProcessing.TypeVector,
                createByDefault=True,
                defaultValue=None
            )
        )

    def processAlgorithm(self, parameters, context, model_feedback):
        feedback = QgsProcessingMultiStepFeedback(7, model_feedback)
        results = {}
        outputs = {}

        # Mesclar_linhas
        alg_params = {
            'CRS': None,
            'LAYERS': parameters[self.INPUT_LINHAS],
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['Mesclar_linhas'] = processing.run('native:mergevectorlayers', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(1)
        if feedback.isCanceled():
            return {}

        # Reprojetar
        alg_params = {
            'INPUT': outputs['Mesclar_linhas']['OUTPUT'],
            'OPERATION': '',
            'TARGET_CRS': QgsCoordinateReferenceSystem('EPSG:32722'),
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['Reprojetar'] = processing.run('native:reprojectlayer', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(2)
        if feedback.isCanceled():
            return {}

        # Calculadora_ID
        alg_params = {
            'FIELD_LENGTH': 0,
            'FIELD_NAME': 'ID',
            'FIELD_PRECISION': 0,
            'FIELD_TYPE': 1,  # Inteiro (32 bit)
            'FORMULA': ' $id ',
            'INPUT': outputs['Reprojetar']['OUTPUT'],
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['Calculadora_id'] = processing.run('native:fieldcalculator', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(3)
        if feedback.isCanceled():
            return {}

        # Pontos_originais (Interpolados)
        alg_params = {
            'DISTANCE': 0.05,
            'END_OFFSET': 0,
            'INPUT': outputs['Calculadora_id']['OUTPUT'],
            'START_OFFSET': 0,
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['Pontos_originais'] = processing.run('native:pointsalonglines', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(4)
        if feedback.isCanceled():
            return {}

        # offset
        alg_params = {
            'COUNT': 1,
            'INPUT': outputs['Calculadora_id']['OUTPUT'],
            'JOIN_STYLE': 0,  # Arredondado
            'MITER_LIMIT': 2,
            'OFFSET': 0.7,
            'SEGMENTS': 8,
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['Offset'] = processing.run('native:arrayoffsetlines', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(5)
        if feedback.isCanceled():
            return {}

        # Extrair_offset
        alg_params = {
            'FIELD': 'offset',
            'INPUT': outputs['Offset']['OUTPUT'],
            'OPERATOR': 1,  # ≠
            'VALUE': '0',
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['Extrair_offset'] = processing.run('native:extractbyattribute', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(6)
        if feedback.isCanceled():
            return {}

        # Pontos_offset (pt)
        alg_params = {
            'DISTANCE': 4,
            'END_OFFSET': 0,
            'INPUT': outputs['Extrair_offset']['OUTPUT'],
            'START_OFFSET': 0,
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['Pontos_offset'] = processing.run('native:pointsalonglines', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        # Carregar camadas temporárias diretamente do contexto
        pt_layer = context.getMapLayer(outputs['Pontos_offset']['OUTPUT'])
        interpolated_layer = context.getMapLayer(outputs['Pontos_originais']['OUTPUT'])

        if not pt_layer or not interpolated_layer:
            raise QgsProcessingException("Invalid temporary layers")

        # Criar estrutura de campos com ambas as classificações
        fields = QgsFields()
        fields.append(QgsField("comp_entr", QVariant.Double))
        fields.append(QgsField("Classe_1.4-1.6", QVariant.String))
        fields.append(QgsField("Classe_1.35-1.65", QVariant.String))
        
        (sink, dest_id) = self.parameterAsSink(
            parameters,
            self.OUTPUT_LINES,
            context,
            fields,
            QgsWkbTypes.LineString,
            pt_layer.sourceCrs()
        )
        
        if sink is None:
            raise QgsProcessingException("Could not create output layer")
        
        feedback.pushInfo("Creating spatial index...")
        index = QgsSpatialIndex(interpolated_layer.getFeatures())
        
        # Carregar pontos interpolados na memória
        feedback.pushInfo("Loading interpolated points into memory...")
        interpolated_points = {}
        for feat in interpolated_layer.getFeatures():
            interpolated_points[feat.id()] = (feat["ID"], feat.geometry().asPoint())
        
        features_to_add = []
        total = pt_layer.featureCount() if pt_layer.featureCount() else 1
        
        for i, pt_feat in enumerate(pt_layer.getFeatures()):
            if feedback.isCanceled():
                return {}
            
            pt_geom = pt_feat.geometry()
            pt = pt_geom.asPoint()
            
            nearest_ids = index.nearestNeighbor(pt, 50)  # Buscar os 50 pontos mais próximos
            pontos_proximos = []
            
            for fid in nearest_ids:
                linha_id, ponto = interpolated_points[fid]  # Busca direta no dicionário
                distancia = pt_geom.distance(QgsGeometry.fromPointXY(ponto))
                
                if distancia <= 2:  # Filtrar por raio máximo de 2 metros
                    pontos_proximos.append((linha_id, ponto, distancia))
            
            pontos_proximos.sort(key=lambda x: x[2])  # Ordenar por distância
            
            pontos_selecionados = {}
            for linha_id, ponto, distancia in pontos_proximos:
                if linha_id not in pontos_selecionados:
                    pontos_selecionados[linha_id] = ponto
                if len(pontos_selecionados) == 2:
                    break
            
            if len(pontos_selecionados) == 2:
                pontos_ordenados = list(pontos_selecionados.values())
                new_geom = QgsGeometry.fromPolylineXY([
                    QgsPointXY(pontos_ordenados[0]),
                    QgsPointXY(pt),
                    QgsPointXY(pontos_ordenados[1])
                ])
                comprimento = new_geom.length()
                
                # Classificação 1.4-1.6
                if 1.4 <= comprimento <= 1.6:
                    classe_1 = "REGULAR"
                else:
                    classe_1 = "IRREGULAR"
                
                # Classificação 1.35-1.65
                if 1.35 <= comprimento <= 1.65:
                    classe_2 = "REGULAR"
                else:
                    classe_2 = "IRREGULAR"
                
                if comprimento < 2.3:
                    new_feat = QgsFeature()
                    new_feat.setGeometry(new_geom)
                    new_feat.setAttributes([comprimento, classe_1, classe_2])
                    features_to_add.append(new_feat)
            
            if i % 500 == 0:  # Atualiza progresso a cada 500 feições
                feedback.setProgress(int((i / total) * 100))
        
        sink.addFeatures(features_to_add, QgsFeatureSink.FastInsert)
        feedback.pushInfo(f"Processing completed: {len(features_to_add)} lines added.")
        
        results[self.OUTPUT_LINES] = dest_id
        
        # Parte do segundo script - análise por categoria (só executa se a camada de polígonos foi fornecida)
        input_polygons = self.parameterAsSource(parameters, self.INPUT_POLYGONS, context)
        if input_polygons:
            feedback.pushInfo("Executando análise por categoria...")
            
            # Criar camada temporária com as linhas geradas
            temp_lines = QgsVectorLayer(f"LineString?crs={pt_layer.sourceCrs().authid()}", "temp_lines", "memory")
            temp_lines_data = temp_lines.dataProvider()
            temp_lines_data.addAttributes(fields)
            temp_lines.updateFields()
            temp_lines_data.addFeatures(features_to_add)
            
            # Executar interseção
            intersection = processing.run(
                "native:intersection",
                {
                    'INPUT': temp_lines,
                    'OVERLAY': parameters[self.INPUT_POLYGONS],
                    'INPUT_FIELDS': ['Classe_1.4-1.6', 'Classe_1.35-1.65'],
                    'OVERLAY_FIELDS': ['KEY'],
                    'OUTPUT': 'memory:'
                },
                context=context,
                feedback=feedback
            )['OUTPUT']

            # Contadores por KEY para ambas as classificações
            total_por_key = {}
            regulares_1_por_key = {}
            irregulares_2_por_key = {}

            feedback.pushInfo("Calculando porcentagens por categoria...")
            for feat in intersection.getFeatures():
                key = feat['KEY']
                classe_1 = feat['Classe_1.4-1.6']
                classe_2 = feat['Classe_1.35-1.65']

                total_por_key[key] = total_por_key.get(key, 0) + 1
                if str(classe_1).strip().upper() == "REGULAR":
                    regulares_1_por_key[key] = regulares_1_por_key.get(key, 0) + 1
                if str(classe_2).strip().upper() == "IRREGULAR":
                    irregulares_2_por_key[key] = irregulares_2_por_key.get(key, 0) + 1

            # Criar camada de saída (sem geometria) - MODIFICADA CONFORME SOLICITADO
            stats_fields = QgsFields()
            stats_fields.append(QgsField("KEY", QVariant.String))
            stats_fields.append(QgsField("Total", QVariant.Int))
            stats_fields.append(QgsField("Regulares", QVariant.Int))
            stats_fields.append(QgsField("Aderencia_paralelismo", QVariant.Double))
            stats_fields.append(QgsField("Irregulares", QVariant.Int))
            stats_fields.append(QgsField("Risco_amassamento", QVariant.Double))

            (stats_sink, stats_dest_id) = self.parameterAsSink(
                parameters,
                self.OUTPUT_STATS,
                context,
                stats_fields,
                QgsWkbTypes.NoGeometry,
                input_polygons.sourceCrs()
            )

            for key in total_por_key:
                total = total_por_key[key]
                regulares_1 = regulares_1_por_key.get(key, 0)
                irregulares_2 = irregulares_2_por_key.get(key, 0)
                percentual_reg_1 = (regulares_1 / total) * 100 if total > 0 else 0
                percentual_irr_2 = (irregulares_2 / total) * 100 if total > 0 else 0

                feat = QgsFeature()
                feat.setFields(stats_fields)
                feat['KEY'] = key
                feat['Total'] = total
                feat['Regulares'] = regulares_1
                feat['Aderencia_paralelismo'] = percentual_reg_1
                feat['Irregulares'] = irregulares_2
                feat['Risco_amassamento'] = percentual_irr_2
                stats_sink.addFeature(feat, QgsFeatureSink.FastInsert)

            results[self.OUTPUT_STATS] = stats_dest_id
        
        return results
