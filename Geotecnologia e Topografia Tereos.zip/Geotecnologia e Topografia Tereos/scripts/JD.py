# -*- coding: utf-8 -*-
"""
Média em grade por pontos (multi-entradas) -> Voronoi -> Filtro por área
Versão: 2025-10-30 (fix context.getMapLayer)
Autor: Eduardo Leoncio
"""

import os, glob, math
from qgis.PyQt.QtCore import QVariant
from qgis.core import (
    QgsProject, QgsVectorLayer, QgsWkbTypes, QgsFeature, QgsFields, QgsField,
    QgsGeometry, QgsPointXY, QgsCoordinateReferenceSystem, QgsCoordinateTransform,
    QgsProcessing, QgsProcessingAlgorithm, QgsProcessingException,
    QgsProcessingParameterMultipleLayers, QgsProcessingParameterFile,
    QgsProcessingParameterString, QgsProcessingParameterNumber,
    QgsProcessingParameterCrs, QgsProcessingParameterFeatureSink, QgsFeatureSink,
    QgsProcessingMultiStepFeedback
)
import processing


class GridMean_Voronoi_Filter(QgsProcessingAlgorithm):
    # Parâmetros
    P_INPUT_LAYERS = "INPUT_LAYERS"
    P_INPUT_DIR    = "INPUT_DIR"
    P_GLOB         = "GLOB_PATTERN"
    P_FIELD        = "FIELD_NAME"
    P_CELL         = "CELL"
    P_WCRS         = "WORK_CRS"
    P_AREA_THRESH  = "AREA_THRESHOLD"
    P_BUFFER       = "BUFFER"
    # Saídas
    P_POINTS_OUT   = "POINTS_OUT"
    P_POLY_OUT     = "POLYGONS_OUT"

    # Metadados
    def name(self): return "grid_mean_voronoi_filter"
    def displayName(self): return "Pontos para Coverages (JohnDeere - OPC)"
    def group(self): return "Processamento de Dados"
    def groupId(self): return "processamento_de_dados"
    def shortHelpString(self):
        return (
            "1) Agrega múltiplas camadas/pastas de pontos em uma grade (m), gerando pontos-centro com média e contagem.\n"
            "2) Constrói polígonos de Voronoi a partir desses pontos.\n"
            "3) Extrai apenas os polígonos com área menor que o limiar informado.\n\n"
            "Saídas: POINTS_OUT (pontos), POLYGONS_OUT (Voronoi filtrado)."
        )
    def createInstance(self): return GridMean_Voronoi_Filter()

    # UI
    def initAlgorithm(self, _config=None):
        self.addParameter(QgsProcessingParameterMultipleLayers(
            self.P_INPUT_LAYERS, "Camadas (múltiplas) – pontos",
            QgsProcessing.TypeVectorPoint, optional=True))

        self.addParameter(QgsProcessingParameterFile(
            self.P_INPUT_DIR, "Pasta (opcional) com arquivos (SHP/GeoJSON/GPKG)",
            behavior=QgsProcessingParameterFile.Folder, optional=True))

        self.addParameter(QgsProcessingParameterString(
            self.P_GLOB, "Padrões de arquivo (separados por ';')",
            defaultValue="*.shp;*.geojson;*.gpkg"))

        self.addParameter(QgsProcessingParameterString(
            self.P_FIELD, "Campo numérico por nome (ex.: TAXA, VALOR_APLIC)",
            defaultValue="AppliedRate"))

        self.addParameter(QgsProcessingParameterNumber(
            self.P_CELL, "Tamanho da célula (m)",
            QgsProcessingParameterNumber.Double, defaultValue=10.0, minValue=0.1))

        self.addParameter(QgsProcessingParameterCrs(
            self.P_WCRS, "CRS de trabalho (cálculo/saída pontos)",
            defaultValue=QgsCoordinateReferenceSystem("EPSG:31982")))

        self.addParameter(QgsProcessingParameterNumber(
            self.P_AREA_THRESH, "Limiar de área para filtro (m²)",
            QgsProcessingParameterNumber.Double, defaultValue=101.0, minValue=0.0))

        self.addParameter(QgsProcessingParameterNumber(
            self.P_BUFFER, "Buffer do Voronoi (m)",
            QgsProcessingParameterNumber.Double, defaultValue=0.0))

        self.addParameter(QgsProcessingParameterFeatureSink(
            self.P_POINTS_OUT, "Pontos (média por célula)"))

        self.addParameter(QgsProcessingParameterFeatureSink(
            self.P_POLY_OUT, "Polígonos Voronoi filtrados"))

    # Carregar camadas de uma pasta
    def _load_point_layers_from_dir(self, directory, patterns, feedback):
        loaded = []

        def load_simple_vector(path):
            lyr = QgsVectorLayer(path, os.path.basename(path), "ogr")
            if lyr.isValid() and QgsWkbTypes.geometryType(lyr.wkbType()) == QgsWkbTypes.PointGeometry:
                loaded.append(lyr)

        def load_gpkg_all_point_layers(path):
            tmp = QgsVectorLayer(path, "", "ogr")
            if not tmp.isValid():
                return
            for sl in tmp.dataProvider().subLayers():
                parts = sl.split(':')
                if len(parts) >= 2:
                    layer_name = parts[1]
                    uri = f"{path}|layername={layer_name}"
                    lyr = QgsVectorLayer(uri, f"{os.path.basename(path)}::{layer_name}", "ogr")
                    if lyr.isValid() and QgsWkbTypes.geometryType(lyr.wkbType()) == QgsWkbTypes.PointGeometry:
                        loaded.append(lyr)

        pats = [p.strip() for p in patterns.split(';') if p.strip()]
        for pat in pats:
            for filepath in glob.glob(os.path.join(directory, pat)):
                ext = os.path.splitext(filepath.lower())[1]
                if ext in (".shp", ".geojson", ".json"):
                    load_simple_vector(filepath)
                elif ext == ".gpkg":
                    load_gpkg_all_point_layers(filepath)
                else:
                    load_simple_vector(filepath)

        feedback.pushInfo(f"Camadas carregadas da pasta: {len(loaded)}")
        return loaded

    # Execução
    def processAlgorithm(self, p, context, model_feedback):
        feedback = QgsProcessingMultiStepFeedback(3, model_feedback)

        # Entradas
        layers = self.parameterAsLayerList(p, self.P_INPUT_LAYERS, context) or []
        directory  = self.parameterAsFile(p, self.P_INPUT_DIR, context)
        patterns   = self.parameterAsString(p, self.P_GLOB, context)
        field_name = self.parameterAsString(p, self.P_FIELD, context)
        cell       = float(self.parameterAsDouble(p, self.P_CELL, context))
        work_crs   = self.parameterAsCrs(p, self.P_WCRS, context)
        area_thr   = float(self.parameterAsDouble(p, self.P_AREA_THRESH, context))
        vor_buffer = float(self.parameterAsDouble(p, self.P_BUFFER, context))

        if directory:
            layers.extend(self._load_point_layers_from_dir(directory, patterns, feedback))
        if not layers:
            raise QgsProcessingException("Nenhuma camada de pontos fornecida (selecione camadas e/ou uma pasta).")
        if not field_name:
            raise QgsProcessingException("Informe o nome do campo numérico a agregar.")
        if cell <= 0:
            raise QgsProcessingException("O tamanho da célula deve ser > 0.")

        proj = QgsProject.instance()

        # Validar camadas + preparar transforms
        valid_layers, transforms = [], {}
        for lyr in layers:
            if not isinstance(lyr, QgsVectorLayer) or not lyr.isValid():
                continue
            if QgsWkbTypes.geometryType(lyr.wkbType()) != QgsWkbTypes.PointGeometry:
                continue
            if lyr.fields().indexFromName(field_name) < 0:
                feedback.pushWarning(f"[Ignorado] Campo '{field_name}' não encontrado em: {lyr.name()}")
                continue
            transforms[lyr.id()] = QgsCoordinateTransform(lyr.crs(), work_crs, proj)
            valid_layers.append(lyr)

        if not valid_layers:
            raise QgsProcessingException(f"Nenhuma camada válida com o campo '{field_name}' foi encontrada.")

        # Extensão total no CRS de trabalho
        first = True
        for lyr in valid_layers:
            ext = lyr.extent()
            corners = [
                QgsPointXY(ext.xMinimum(), ext.yMinimum()),
                QgsPointXY(ext.xMinimum(), ext.yMaximum()),
                QgsPointXY(ext.xMaximum(), ext.yMinimum()),
                QgsPointXY(ext.xMaximum(), ext.yMaximum())
            ]
            xs, ys = [], []
            tr = transforms[lyr.id()]
            for pnt in corners:
                pw = tr.transform(pnt)
                xs.append(pw.x()); ys.append(pw.y())
            xmin, xmax = min(xs), max(xs)
            ymin, ymax = min(ys), max(ys)
            if first:
                XMIN, XMAX, YMIN, YMAX = xmin, xmax, ymin, ymax
                first = False
            else:
                XMIN = min(XMIN, xmin); XMAX = max(XMAX, xmax)
                YMIN = min(YMIN, ymin); YMAX = max(YMAX, ymax)

        if (XMAX - XMIN) < cell: XMAX = XMIN + cell
        if (YMAX - YMIN) < cell: YMAX = YMIN + cell
        x0 = math.floor(XMIN / cell) * cell
        y0 = math.floor(YMIN / cell) * cell

        # Agregação em work_crs
        acc = {}  # (col,row) -> [soma, cont]
        total_feats = sum(lyr.featureCount() for lyr in valid_layers) or 1
        processed = 0

        for lyr in valid_layers:
            fld_idx = lyr.fields().indexFromName(field_name)
            tr = transforms[lyr.id()]
            for ft in lyr.getFeatures():
                if feedback.isCanceled(): break
                processed += 1
                if processed % 2000 == 0:
                    feedback.setProgress(int(100 * processed / total_feats))
                geom = ft.geometry()
                if not geom or geom.isEmpty(): continue
                pt = geom.asPoint()
                pw = tr.transform(QgsPointXY(pt))
                x, y = pw.x(), pw.y()
                col = int(math.floor((x - x0) / cell))
                row = int(math.floor((y - y0) / cell))
                try:
                    v = float(ft[fld_idx])
                except Exception:
                    continue
                key = (col, row)
                if key in acc:
                    acc[key][0] += v; acc[key][1] += 1
                else:
                    acc[key] = [v, 1]

        safe_field = "".join(ch if (ch.isalnum() or ch == "_") else "_" for ch in field_name).strip("_")
        out_fields = QgsFields()
        out_fields.append(QgsField("__col", QVariant.Int))
        out_fields.append(QgsField("__row", QVariant.Int))
        out_fields.append(QgsField("count", QVariant.Int))
        out_fields.append(QgsField(f"mean_{safe_field}", QVariant.Double))

        (points_sink, points_id) = self.parameterAsSink(
            p, self.P_POINTS_OUT, context, out_fields, QgsWkbTypes.Point, work_crs)
        if points_sink is None:
            raise QgsProcessingException("Não foi possível criar a saída de pontos.")

        for (col, row), (soma, cont) in acc.items():
            cx = x0 + (col + 0.5) * cell
            cy = y0 + (row + 0.5) * cell
            f = QgsFeature(out_fields)
            f.setGeometry(QgsGeometry.fromPointXY(QgsPointXY(cx, cy)))
            f["__col"] = col; f["__row"] = row
            f["count"] = cont
            f[f"mean_{safe_field}"] = (soma / cont) if cont else None
            points_sink.addFeature(f, QgsFeatureSink.FastInsert)

        feedback.pushInfo(f"[1/3] Pontos gerados: {len(acc)} | Feições processadas: {processed}")

        # Voronoi (resultado temporário dentro do contexto)
        feedback.setCurrentStep(1)
        vor_params = {
            'BUFFER': vor_buffer,
            'COPY_ATTRIBUTES': True,
            'INPUT': points_id,
            'TOLERANCE': 0.0,
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        vor = processing.run(
            'native:voronoipolygons',
            vor_params,
            context=context,
            feedback=feedback,
            is_child_algorithm=True
        )

        # Obter camada Voronoi diretamente do contexto (NÃO usar QgsVectorLayer(path, ...))
        vor_layer = context.getMapLayer(vor['OUTPUT'])
        if vor_layer is None or not vor_layer.isValid():
            raise QgsProcessingException("Falha ao carregar camada Voronoi (contexto retornou None).")

        # Filtro por área
        feedback.setCurrentStep(2)
        expr = f"$area < {area_thr}"
        ext_params = {
            'EXPRESSION': expr,
            'INPUT': vor['OUTPUT'],  # pode passar o ID do layer temporário
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        ext = processing.run(
            'native:extractbyexpression',
            ext_params,
            context=context,
            feedback=feedback,
            is_child_algorithm=True
        )

        # Obter camada filtrada do contexto
        ext_layer = context.getMapLayer(ext['OUTPUT'])
        if ext_layer is None or not ext_layer.isValid():
            raise QgsProcessingException("Falha ao carregar camada filtrada (contexto retornou None).")

        (poly_sink, poly_id) = self.parameterAsSink(
            p, self.P_POLY_OUT, context,
            ext_layer.fields(), QgsWkbTypes.Polygon, ext_layer.sourceCrs())
        if poly_sink is None:
            raise QgsProcessingException("Não foi possível criar a saída de polígonos.")

        for f in ext_layer.getFeatures():
            poly_sink.addFeature(f, QgsFeatureSink.FastInsert)

        feedback.pushInfo(f"[2/3] Voronoi gerado | [3/3] Filtro '{expr}' aplicado")
        return {self.P_POINTS_OUT: points_id, self.P_POLY_OUT: poly_id}
