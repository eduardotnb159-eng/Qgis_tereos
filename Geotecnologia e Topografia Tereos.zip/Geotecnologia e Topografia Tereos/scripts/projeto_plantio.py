# -*- coding: utf-8 -*-
"""
Mesclar LineFeature (bloco + parte de pasta)
Versão segura (usa arquivos temporários no disco, CRS unificado)
- BLOCO = penúltima pasta
- PARTE = última pasta
- Saída: .shp
"""

import os, re, unicodedata, tempfile, shutil
from pathlib import Path
from qgis.PyQt.QtCore import QCoreApplication
from qgis.core import (
    QgsVectorLayer, QgsProcessing, QgsProcessingAlgorithm,
    QgsProcessingParameterFile, QgsProcessingParameterBoolean,
    QgsProcessingParameterVectorDestination, QgsProcessingException
)
import processing


class MesclarLineFeatureBlocoPartePastas(QgsProcessingAlgorithm):
    P_IN_DIR = "IN_DIR"
    P_SANITIZE = "SANITIZE"
    P_OUT = "OUT"

    def tr(self, s): return QCoreApplication.translate("MesclarLF", s)
    def createInstance(self): return MesclarLineFeatureBlocoPartePastas()
    def name(self): return "mesclar_linefeature_bloco_parte_pasta"
    def displayName(self): return self.tr("Mesclar Linhas de Projetos (AgGPS)")
    def group(self): return self.tr("Projetos de Linhas")
    def groupId(self): return "projeto_de_linhas"

    def shortHelpString(self):
        return self.tr(
            "Procura LineFeature*.shp em subpastas. Cria campos: "
            "BLOCO = penúltima pasta; PARTE = última pasta. "
            "Unifica CRS, usa temporários em disco e mescla em um único Shapefile (.shp)."
        )

    # ========= helpers =========
    def _slug_field(self, name: str):
        """Limpa nomes de campos (ASCII, <=10 chars)"""
        import unicodedata, re
        nfkd = unicodedata.normalize("NFKD", name)
        s = "".join(ch for ch in nfkd if not unicodedata.combining(ch))
        s = re.sub(r"[^A-Za-z0-9_]", "_", s)
        if re.match(r"^\d", s): s = "_" + s
        if not s: s = "field"
        return s[:10]

    # ========= parâmetros =========
    def initAlgorithm(self, config=None):
        self.addParameter(
            QgsProcessingParameterFile(
                self.P_IN_DIR, self.tr("Pasta raiz"),
                behavior=QgsProcessingParameterFile.Folder
            )
        )
        self.addParameter(
            QgsProcessingParameterBoolean(
                self.P_SANITIZE, self.tr("Sanear nomes de campos (limite 10 chars do SHP)"),
                defaultValue=True
            )
        )
        self.addParameter(
            QgsProcessingParameterVectorDestination(
                self.P_OUT, self.tr("Saída final (.shp)"),
                type=QgsProcessing.TypeVectorAnyGeometry
            )
        )

    # ========= processamento =========
    def processAlgorithm(self, params, context, feedback):
        in_dir = self.parameterAsFile(params, self.P_IN_DIR, context)
        do_sanitize = self.parameterAsBool(params, self.P_SANITIZE, context)
        out_path = self.parameterAsOutputLayer(params, self.P_OUT, context)

        if not os.path.isdir(in_dir):
            raise QgsProcessingException("Pasta de entrada inválida.")

        rx = re.compile(r"^linefeature.*\.shp$", re.IGNORECASE)
        shp_list = [Path(r) / f for r, _, fs in os.walk(in_dir) for f in fs if rx.match(f)]
        if not shp_list:
            raise QgsProcessingException("Nenhum 'LineFeature*.shp' encontrado.")

        feedback.pushInfo(f"Encontrados {len(shp_list)} arquivos.")
        tmpdir = tempfile.mkdtemp(prefix="merge_lf_")
        feedback.pushInfo(f"Usando pasta temporária: {tmpdir}")

        prepped_layers = []
        first_crs = None

        for i, p in enumerate(shp_list, 1):
            if feedback.isCanceled():
                break

            vl = QgsVectorLayer(str(p), p.stem, "ogr")
            if not vl or not vl.isValid():
                feedback.pushWarning(f"[{i}] inválido: {p}")
                continue
            if vl.featureCount() == 0:
                feedback.pushInfo(f"[{i}] vazio: {p}")
                continue

            # CRS base
            if first_crs is None:
                first_crs = vl.crs()
                feedback.pushInfo(f"CRS base definido: {first_crs.authid()}")

            # valores a partir das pastas
            parte_val = p.parent.name                          # última pasta
            bloco_val = p.parent.parent.name if p.parent.parent else ""  # penúltima pasta

            # reprojectar se necessário
            src_path = str(p)
            if vl.crs() != first_crs:
                reproj_path = os.path.join(tmpdir, f"reproj_{i}.shp")
                processing.run(
                    "native:reprojectlayer",
                    {"INPUT": src_path, "TARGET_CRS": first_crs, "OUTPUT": reproj_path},
                    context=context, feedback=feedback
                )
                src_path = reproj_path

            # 1) adicionar BLOCO
            step1 = os.path.join(tmpdir, f"bloco_{i}.shp")
            processing.run(
                "native:fieldcalculator",
                {
                    "INPUT": src_path,
                    "FIELD_NAME": "BLOCO",
                    "FIELD_TYPE": 2,            # String
                    "NEW_FIELD": True,
                    "FIELD_LENGTH": 20,
                    "FIELD_PRECISION": 0,
                    "FORMULA": f"to_string('{bloco_val}')",
                    "OUTPUT": step1
                },
                context=context, feedback=feedback
            )

            # 2) adicionar PARTE (última pasta)
            #   - se campo PARTE já existir, atualizar; senão, criar
            lyr1 = QgsVectorLayer(step1, "lyr1", "ogr")
            has_parte = any(f.name().lower() == "parte" for f in lyr1.fields())

            step2 = os.path.join(tmpdir, f"parte_{i}.shp")
            if has_parte:
                # atualiza campo existente
                processing.run(
                    "native:fieldcalculator",
                    {
                        "INPUT": step1,
                        "FIELD_NAME": "PARTE",
                        "FIELD_TYPE": 2,        # ignorado quando NEW_FIELD=False
                        "NEW_FIELD": False,     # Atualiza campo existente
                        "FIELD_LENGTH": 20,
                        "FIELD_PRECISION": 0,
                        "FORMULA": f"to_string('{parte_val}')",
                        "OUTPUT": step2
                    },
                    context=context, feedback=feedback
                )
            else:
                # cria novo campo PARTE
                processing.run(
                    "native:fieldcalculator",
                    {
                        "INPUT": step1,
                        "FIELD_NAME": "PARTE",
                        "FIELD_TYPE": 2,
                        "NEW_FIELD": True,
                        "FIELD_LENGTH": 20,
                        "FIELD_PRECISION": 0,
                        "FORMULA": f"to_string('{parte_val}')",
                        "OUTPUT": step2
                    },
                    context=context, feedback=feedback
                )

            src_final = step2

            # 3) sanitização opcional de nomes (para SHP)
            if do_sanitize:
                fields = QgsVectorLayer(src_final, "srcf", "ogr").fields()
                field_map, seen = [], set()
                for f in fields:
                    nn = self._slug_field(f.name())
                    if nn.lower() in seen:
                        nn = nn[:8] + "_x"
                    seen.add(nn.lower())
                    field_map.append({
                        "expression": f'"{f.name()}"',
                        "length": f.length(),
                        "name": nn,
                        "precision": f.precision(),
                        "type": f.type()
                    })
                step3 = os.path.join(tmpdir, f"clean_{i}.shp")
                processing.run(
                    "native:refactorfields",
                    {"INPUT": src_final, "FIELDS_MAPPING": field_map, "OUTPUT": step3},
                    context=context, feedback=feedback
                )
                prepped_layers.append(step3)
            else:
                prepped_layers.append(src_final)

            feedback.pushInfo(f"[{i}] {p.name}: BLOCO='{bloco_val}', PARTE='{parte_val}', feições={vl.featureCount()}")

        # MESCLAR
        feedback.pushInfo(f"Mesclando {len(prepped_layers)} camadas...")
        merge = processing.run(
            "native:mergevectorlayers",
            {"LAYERS": prepped_layers, "CRS": first_crs, "OUTPUT": out_path},
            context=context, feedback=feedback
        )

        # limpar temporários
        try: shutil.rmtree(tmpdir)
        except Exception: pass

        feedback.pushInfo(f"Saída final: {merge['OUTPUT']}")
        return {self.P_OUT: merge["OUTPUT"]}
