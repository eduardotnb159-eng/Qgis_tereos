from qgis.core import QgsProcessing
from qgis.core import QgsProcessingAlgorithm
from qgis.core import QgsProcessingMultiStepFeedback
from qgis.core import QgsProcessingParameterVectorLayer
from qgis.core import QgsProcessingParameterFeatureSink
from qgis.core import QgsProcessingParameterField
from qgis.core import QgsCoordinateReferenceSystem
import processing


class pontosparacoverage(QgsProcessingAlgorithm):

    def initAlgorithm(self, config=None):
        self.addParameter(QgsProcessingParameterVectorLayer('pontos', 'Pontos', types=[QgsProcessing.TypeVectorPoint], defaultValue=None))
        self.addParameter(QgsProcessingParameterField('campo_taxa', 'Campo de Taxa de Aplicação', type=QgsProcessingParameterField.Any, parentLayerParameterName='pontos', allowMultiple=False, defaultValue='AppliedRate'))
        self.addParameter(QgsProcessingParameterFeatureSink('Coverage', 'Coverage', type=QgsProcessing.TypeVectorAnyGeometry, createByDefault=True, supportsAppend=True, defaultValue=None))

    def processAlgorithm(self, parameters, context, model_feedback):
        feedback = QgsProcessingMultiStepFeedback(14, model_feedback)
        results = {}
        outputs = {}

        # Verificar campo de taxa e converter se necessário
        campo_taxa = self.parameterAsString(parameters, 'campo_taxa', context)
        layer_original = self.parameterAsVectorLayer(parameters, 'pontos', context)
        
        # Informações do campo escolhido
        fields = layer_original.fields()
        field_index = fields.indexFromName(campo_taxa)
        
        if field_index == -1:
            feedback.reportError(f'Campo {campo_taxa} não encontrado na camada')
            return {}
            
        field_type = fields.field(field_index).type()
        
        # Converter para double
        if field_type != 6:  # 6 = double
            # Para campos string, substituir vírgula por ponto e converter para double
            if field_type == 10:  # 10 = string
                expression = f'replace(to_string("{campo_taxa}"), \',\', \'.\')'
            else:
                # Para outros tipos numéricos
                expression = f'to_real("{campo_taxa}")'
                
            alg_params = {
                'FIELDS_MAPPING': [
                    {
                        'expression': expression,
                        'length': 17,
                        'name': 'tx_a',
                        'precision': 9,
                        'type': 6  # double
                    }
                ],
                'INPUT': parameters['pontos'],
                'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
            }
            outputs['ConverterCampo'] = processing.run('native:refactorfields', alg_params, context=context, feedback=feedback, is_child_algorithm=True)
            layer_para_reprojetar = outputs['ConverterCampo']['OUTPUT']
        else:
            # renomear
            alg_params = {
                'FIELDS_MAPPING': [
                    {
                        'expression': f'"{campo_taxa}"',
                        'length': 17,
                        'name': 'tx_a',
                        'precision': 9,
                        'type': 6  # double
                    }
                ],
                'INPUT': parameters['pontos'],
                'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
            }
            outputs['ConverterCampo'] = processing.run('native:refactorfields', alg_params, context=context, feedback=feedback, is_child_algorithm=True)
            layer_para_reprojetar = outputs['ConverterCampo']['OUTPUT']

        feedback.setCurrentStep(1)
        if feedback.isCanceled():
            return {}

        # Reprojetar para tum
        alg_params = {
            'CONVERT_CURVED_GEOMETRIES': False,
            'INPUT': layer_para_reprojetar,
            'OPERATION': '',
            'TARGET_CRS': QgsCoordinateReferenceSystem('EPSG:31982'),
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['ReprojetarCamada'] = processing.run('native:reprojectlayer', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(2)
        if feedback.isCanceled():
            return {}

        # Limpar pontos
        alg_params = {
            'EXPRESSION': '"tx_a">0\r\nAND\r\n"tx_a"<60000',
            'INPUT': outputs['ReprojetarCamada']['OUTPUT'],
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['ExtrairPorExpresso'] = processing.run('native:extractbyexpression', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(3)
        if feedback.isCanceled():
            return {}

        # Criar área de interesse
        alg_params = {
            'DISSOLVE': False,
            'DISTANCE': 10,
            'END_CAP_STYLE': 2,  # Quadrado
            'INPUT': outputs['ExtrairPorExpresso']['OUTPUT'],
            'JOIN_STYLE': 2,  # Chanfrado
            'MITER_LIMIT': 2,
            'SEGMENTS': 5,
            'SEPARATE_DISJOINT': False,
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['Buffer'] = processing.run('native:buffer', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(4)
        if feedback.isCanceled():
            return {}

        # Dissolver área de interesse
        alg_params = {
            'FIELD': [''],
            'INPUT': outputs['Buffer']['OUTPUT'],
            'SEPARATE_DISJOINT': False,
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['Dissolver'] = processing.run('native:dissolve', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(5)
        if feedback.isCanceled():
            return {}

        # Criar grade
        alg_params = {
            'CRS': QgsCoordinateReferenceSystem('EPSG:31982'),
            'EXTENT': outputs['Dissolver']['OUTPUT'],
            'HOVERLAY': 0,
            'HSPACING': 10,
            'TYPE': 2,  # Retângulo (Polígono)
            'VOVERLAY': 0,
            'VSPACING': 10,
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['CriarGrade'] = processing.run('native:creategrid', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(6)
        if feedback.isCanceled():
            return {}

        # Editar campos grade
        alg_params = {
            'FIELDS_MAPPING': [{'alias': '','comment': '','expression': '"id"','length': 0,'name': 'id','precision': 0,'sub_type': 0,'type': 4,'type_name': 'int8'}],
            'INPUT': outputs['CriarGrade']['OUTPUT'],
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['EditarCamposGrade'] = processing.run('native:refactorfields', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(7)
        if feedback.isCanceled():
            return {}

        # Associar id grade para pontos
        alg_params = {
            'DISCARD_NONMATCHING': False,
            'INPUT': outputs['ExtrairPorExpresso']['OUTPUT'],
            'JOIN': outputs['EditarCamposGrade']['OUTPUT'],
            'JOIN_FIELDS': [''],
            'METHOD': 0,  # Criar feição separada para cada feição correspondente (um-para-muitos)
            'PREDICATE': [0],  # interseccionam
            'PREFIX': '',
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['AssociarAtributosPorLocalizao'] = processing.run('native:joinattributesbylocation', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(8)
        if feedback.isCanceled():
            return {}

        # Média da taxa por id grade
        alg_params = {
            'CATEGORIES_FIELD_NAME': ['id'],
            'INPUT': outputs['AssociarAtributosPorLocalizao']['OUTPUT'],
            'VALUES_FIELD_NAME': 'tx_a',
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['EstatsticasPorCategoria'] = processing.run('qgis:statisticsbycategories', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(9)
        if feedback.isCanceled():
            return {}

        # Editar campos mean
        alg_params = {
            'FIELDS_MAPPING': [{'alias': '','comment': '','expression': '"id"','length': 0,'name': 'id','precision': 0,'sub_type': 0,'type': 4,'type_name': 'int8'},{'alias': '','comment': '','expression': '"mean"','length': 0,'name': 'mean','precision': 0,'sub_type': 0,'type': 6,'type_name': 'double precision'}],
            'INPUT': outputs['EstatsticasPorCategoria']['OUTPUT'],
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['EditarCamposMean'] = processing.run('native:refactorfields', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(10)
        if feedback.isCanceled():
            return {}

        # Unir atributos para grade
        alg_params = {
            'DISCARD_NONMATCHING': False,
            'FIELD': 'id',
            'FIELDS_TO_COPY': [''],
            'FIELD_2': 'id',
            'INPUT': outputs['EditarCamposGrade']['OUTPUT'],
            'INPUT_2': outputs['EditarCamposMean']['OUTPUT'],
            'METHOD': 1,  # Tomar atributos apenas da primeira feição coincidente (uma-por-uma)
            'PREFIX': '',
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['UnirAtributosPeloValorDoCampo'] = processing.run('native:joinattributestable', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(11)
        if feedback.isCanceled():
            return {}

        # Usar apenas grade com valor
        alg_params = {
            'EXPRESSION': '"id_2">=1',
            'INPUT': outputs['UnirAtributosPeloValorDoCampo']['OUTPUT'],
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['ExtrairPorExpressoFinal'] = processing.run('native:extractbyexpression', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(12)
        if feedback.isCanceled():
            return {}

        # Editar campos para saída final
        alg_params = {
            'FIELDS_MAPPING': [{'alias': '','comment': '','expression': '"mean"','length': 0,'name': 'taxa_1','precision': 0,'sub_type': 0,'type': 4,'type_name': 'int8'}],
            'INPUT': outputs['ExtrairPorExpressoFinal']['OUTPUT'],
            'OUTPUT': parameters['Coverage']
        }
        outputs['EditarCamposFinal'] = processing.run('native:refactorfields', alg_params, context=context, feedback=feedback, is_child_algorithm=True)
        results['Coverage'] = outputs['EditarCamposFinal']['OUTPUT']
        return results

    def name(self):
        return 'pontosparacoverage'

    def displayName(self):
        return 'Pontos para coverage - JohnDeere'

    def group(self):
        return 'Processamento de Dados'

    def groupId(self):
        return 'processamento_de_dados'

    def createInstance(self):
        return pontosparacoverage()

    def shortHelpString(self):
        return ("<html><body>"
                "<h3>Converter pontos para Coverage</h3>"
                "<p>Este algoritmo transforma os pontos de pós-aplicação em polígonos (coverage) para análise da taxa de aplicação via Inceres.</p>"
                "</ul>"
                "<p align='right'><i>Autor: guilherme.dutra1@tereos.com</i></p>"
                "</body></html>")

    
