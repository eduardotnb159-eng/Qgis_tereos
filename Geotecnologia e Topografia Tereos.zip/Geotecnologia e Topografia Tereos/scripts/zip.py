# -*- coding: utf-8 -*-
"""
Compactar Pastas – Projeto de Colheita
Autor: Eduardo Leoncio – Geotecnologia e Topografia

Função:
Percorre a pasta escolhida, localiza subpastas “AgData”, “AgGPS”, “Gen4” ou “GS3_2630”
e gera um ZIP único com todas essas pastas, nomeado:
  <nome_da_pasta>_PROJETO_COLHEITA.zip
O ZIP é criado na raiz da pasta principal.
"""

import os
import zipfile
from pathlib import Path
from qgis.PyQt.QtCore import QCoreApplication
from qgis.core import (
    QgsProcessing,
    QgsProcessingAlgorithm,
    QgsProcessingParameterFile,
    QgsProcessingParameterBoolean,
    QgsProcessingParameterEnum,
    QgsProcessingException,
)
import processing


class CompactarProjetoColheita(QgsProcessingAlgorithm):
    P_IN_DIR = "IN_DIR"
    P_OVERWRITE = "OVERWRITE"

    TARGET_FOLDERS = ["AgData", "AgGPS", "Gen4", "GS3_2630"]
    ZIP_TAG = "_PROJETO_COLHEITA"

    def tr(self, s):
        return QCoreApplication.translate("CompactarProjetoColheita", s)

    def name(self):
        return "compactar_projeto_colheita"

    def displayName(self):
        return self.tr("Compactar Pastas – Projeto de Colheita")

    def group(self):
        return self.tr("Projetos de Linhas")

    def groupId(self):
        return "projeto_de_linhas"

    def createInstance(self):
        return CompactarProjetoColheita()

    def shortHelpString(self):
        return self.tr(
            "Percorre o diretório escolhido e cria um arquivo ZIP contendo as pastas "
            "AgData, AgGPS, Gen4 e GS3_2630, caso existam. "
            "O ZIP é criado na raiz com o nome <pasta>_PROJETO_COLHEITA.zip."
        )

    def initAlgorithm(self, config=None):
        self.addParameter(
            QgsProcessingParameterFile(
                self.P_IN_DIR,
                self.tr("Pasta base"),
                behavior=QgsProcessingParameterFile.Folder,
            )
        )
        self.addParameter(
            QgsProcessingParameterBoolean(
                self.P_OVERWRITE,
                self.tr("Sobrescrever ZIP existente (se houver)"),
                defaultValue=True,
            )
        )

    def processAlgorithm(self, params, context, feedback):
        base_dir = self.parameterAsFile(params, self.P_IN_DIR, context)
        overwrite = self.parameterAsBool(params, self.P_OVERWRITE, context)

        base_path = Path(base_dir)
        if not base_path.exists():
            raise QgsProcessingException("Pasta base inválida.")

        feedback.pushInfo(f"📂 Pasta base: {base_path}")
        found_any = False

        # Percorre recursivamente o diretório
        for root, dirs, _ in os.walk(base_path):
            parent = Path(root)
            subdirs = set(dirs)
            found = [d for d in self.TARGET_FOLDERS if d in subdirs]
            if not found:
                continue

            found_any = True
            zip_name = f"{parent.name}{self.ZIP_TAG}.zip"
            zip_path = parent / zip_name

            if zip_path.exists() and not overwrite:
                feedback.pushInfo(f"⚠ ZIP já existe, pulando: {zip_path}")
                continue

            feedback.pushInfo(f"\n📦 Criando ZIP: {zip_path}")
            feedback.pushInfo(f"  → Incluindo pastas: {', '.join(found)}")

            with zipfile.ZipFile(zip_path, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as zf:
                for folder in found:
                    folder_path = parent / folder
                    for path in folder_path.rglob("*"):
                        if path.is_file():
                            arcname = Path(folder) / path.relative_to(folder_path)
                            zf.write(path, arcname.as_posix())

            feedback.pushInfo(f"✅ ZIP criado com sucesso: {zip_path}")

        if not found_any:
            feedback.pushWarning("Nenhuma pasta de projeto encontrada (AgData, AgGPS, Gen4, GS3_2630).")

        return {}

def classFactory():
    return CompactarProjetoColheita()
