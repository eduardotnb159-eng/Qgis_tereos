# -*- coding: utf-8 -*-
"""
Algoritmo QGIS: Compactar Shapefiles por Nome (ZIP)
- Percorre uma pasta (opcionalmente recursiva)
- Para cada .shp encontrado, identifica o "nome-base" (sem extensão)
- Agrupa todos os arquivos do mesmo shapefile (.shp, .shx, .dbf, .prj, .cpg, .qpj, etc.)
- Cria um ZIP <nome-base>.zip com todos os componentes do shapefile, na pasta de saída
"""

import os
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED

from qgis.PyQt.QtCore import QCoreApplication
from qgis.core import (
    QgsProcessing,
    QgsProcessingAlgorithm,
    QgsProcessingParameterFile,
    QgsProcessingParameterFolderDestination,
    QgsProcessingParameterBoolean,
    QgsProcessingException,
)

class ZipShapefilesByBasename(QgsProcessingAlgorithm):
    P_IN_DIR = "IN_DIR"
    P_OUT_DIR = "OUT_DIR"
    P_RECURSIVE = "RECURSIVE"
    P_OVERWRITE = "OVERWRITE"

    def tr(self, string):
        return QCoreApplication.translate("ZipShapefilesByBasename", string)

    def createInstance(self):
        return ZipShapefilesByBasename()

    def name(self):
        return "zip_shapefiles_by_basename"

    def displayName(self):
        return self.tr("Compactar Arquivos p/ INCERES(ZIP)")

    def group(self):
        return self.tr("Desenvolvimento Tecnico")

    def groupId(self):
        return "desenvolvimento_tecnico"

    def shortHelpString(self):
        return self.tr(
            "Cria um arquivo .zip por shapefile (pelo numero do bloco), incluindo todos os "
            "componentes (.shp, .shx, .dbf, .prj, .cpg, .qpj, .sbn, .sbx, .aih, .ain, .xml, .sld)."
        )

    def initAlgorithm(self, config=None):
        self.addParameter(
            QgsProcessingParameterFile(
                self.P_IN_DIR,
                self.tr("Pasta de entrada (contendo os .shp)"),
                behavior=QgsProcessingParameterFile.Folder,
                fileFilter="",
                defaultValue=None,
            )
        )
        self.addParameter(
            QgsProcessingParameterFolderDestination(
                self.P_OUT_DIR,
                self.tr("Pasta de saída (onde serão salvos os .zip)")
            )
        )
        self.addParameter(
            QgsProcessingParameterBoolean(
                self.P_RECURSIVE,
                self.tr("Buscar em subpastas (recursivo)"),
                defaultValue=False
            )
        )
        self.addParameter(
            QgsProcessingParameterBoolean(
                self.P_OVERWRITE,
                self.tr("Sobrescrever .zip existentes"),
                defaultValue=False
            )
        )

    def processAlgorithm(self, parameters, context, feedback):
        in_dir = Path(self.parameterAsFile(parameters, self.P_IN_DIR, context) or "")
        out_dir = Path(self.parameterAsFile(parameters, self.P_OUT_DIR, context) or "")
        recursive = self.parameterAsBoolean(parameters, self.P_RECURSIVE, context)
        overwrite = self.parameterAsBoolean(parameters, self.P_OVERWRITE, context)

        if not in_dir or not in_dir.exists() or not in_dir.is_dir():
            raise QgsProcessingException(self.tr("Pasta de entrada inválida."))

        out_dir.mkdir(parents=True, exist_ok=True)

        # Extensões comuns que compõem um shapefile
        exts = {
            ".shp", ".shx", ".dbf", ".prj", ".cpg", ".qpj",
            ".sbn", ".sbx", ".aih", ".ain",
            ".sld", ".xml"  # metadados/estilos, se existirem
        }

        # Coleta todos os .shp e seus nomes-base
        shp_files = []
        if recursive:
            iterator = in_dir.rglob("*.shp")
        else:
            iterator = in_dir.glob("*.shp")

        for shp in iterator:
            if shp.is_file():
                shp_files.append(shp)

        if not shp_files:
            feedback.pushInfo(self.tr("Nenhum .shp encontrado."))
            return {self.P_OUT_DIR: str(out_dir)}

        total = len(shp_files)
        for idx, shp_path in enumerate(shp_files, 1):
            if feedback.isCanceled():
                break

            basename = shp_path.stem  # nome-base sem extensão
            folder = shp_path.parent

            # Monta a lista de arquivos do mesmo shapefile (mesmo nome-base)
            component_files = []

            # Inclui explicitamente os conhecidos
            for ext in exts:
                candidate = folder / f"{basename}{ext}"
                if candidate.exists():
                    component_files.append(candidate)

            # Também pega qualquer outro arquivo que comece com o nome-base (ex.: .qmd, .lyr, etc.),
            # MAS do mesmo diretório, para não misturar coisas de subpastas diferentes
            for f in folder.glob(f"{basename}.*"):
                if f not in component_files:
                    component_files.append(f)

            if not component_files:
                feedback.pushInfo(self.tr(f"[AVISO] Sem componentes para: {basename}"))
                continue

            zip_name = f"{basename}.zip"
            zip_path = out_dir / zip_name

            if zip_path.exists() and not overwrite:
                feedback.pushInfo(self.tr(f"[PULAR] Já existe: {zip_name}"))
                continue

            # Cria/atualiza o ZIP
            try:
                with ZipFile(zip_path, mode="w", compression=ZIP_DEFLATED) as zf:
                    for f in component_files:
                        # Coloca os arquivos na raiz do ZIP (apenas o nome do arquivo)
                        zf.write(f, arcname=f.name)
                feedback.pushInfo(self.tr(f"[OK] Gerado: {zip_name}"))
            except Exception as e:
                feedback.reportError(self.tr(f"Falha ao compactar {basename}: {e}"))

            feedback.setProgress(int(idx * 100 / total))

        return {self.P_OUT_DIR: str(out_dir)}
