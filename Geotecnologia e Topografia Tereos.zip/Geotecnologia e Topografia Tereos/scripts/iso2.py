# -*- coding: utf-8 -*-
import os, struct
from qgis.PyQt.QtCore import QCoreApplication, QVariant
from qgis.core import (
    QgsProcessing, QgsProcessingAlgorithm, QgsProcessingException,
    QgsProcessingParameterFile, QgsProcessingParameterFeatureSink,
    QgsProcessingParameterBoolean, QgsProcessingParameterNumber,
    QgsFeature, QgsFields, QgsField, QgsGeometry, QgsPointXY,
    QgsWkbTypes, QgsCoordinateReferenceSystem
)

class ImportarPontosPRO1200Algorithm(QgsProcessingAlgorithm):
    INPUT_FOLDER = "INPUT_FOLDER"
    APPLY_FILTER = "APPLY_FILTER"
    MIN_LAT = "MIN_LAT"
    MAX_LAT = "MAX_LAT"
    MIN_LON = "MIN_LON"
    MAX_LON = "MAX_LON"
    OUTPUT = "OUTPUT"

    def tr(self, s): return QCoreApplication.translate("ImportarPontosPRO1200", s)

    def name(self): return "importar_pontos_pro1200"
    def displayName(self): return self.tr("Importar Pontos - PRO1200")
    def group(self): return self.tr("Processamento de Dados")
    def groupId(self): return "processamento_de_dados"

    def shortHelpString(self):
        return self.tr("Lê .BIN em subpastas e gera pontos (EPSG:4326). "
                       "Opcional: filtro geográfico de Tanabi/SP.")

    # >>> ADIÇÃO CRÍTICA: necessário para o QGIS instanciar o algoritmo <<<
    def createInstance(self):
        return ImportarPontosPRO1200Algorithm()

    def initAlgorithm(self, config=None):
        self.addParameter(
            QgsProcessingParameterFile(
                self.INPUT_FOLDER, self.tr("Pasta raiz contendo arquivos .BIN"),
                behavior=QgsProcessingParameterFile.Folder
            )
        )
        self.addParameter(QgsProcessingParameterBoolean(
            self.APPLY_FILTER, self.tr("Aplicar filtro geográfico (Tanabi/SP)"), defaultValue=True
        ))
        self.addParameter(QgsProcessingParameterNumber(
            self.MIN_LAT, self.tr("Mín. Latitude"), type=QgsProcessingParameterNumber.Double, defaultValue=-20.7
        ))
        self.addParameter(QgsProcessingParameterNumber(
            self.MAX_LAT, self.tr("Máx. Latitude"), type=QgsProcessingParameterNumber.Double, defaultValue=-20.5
        ))
        self.addParameter(QgsProcessingParameterNumber(
            self.MIN_LON, self.tr("Mín. Longitude"), type=QgsProcessingParameterNumber.Double, defaultValue=-49.7
        ))
        self.addParameter(QgsProcessingParameterNumber(
            self.MAX_LON, self.tr("Máx. Longitude"), type=QgsProcessingParameterNumber.Double, defaultValue=-49.5
        ))
        self.addParameter(QgsProcessingParameterFeatureSink(
            self.OUTPUT, self.tr("Pontos importados (EPSG:4326)")
        ))

    def processAlgorithm(self, parameters, context, feedback):
        folder = self.parameterAsFile(parameters, self.INPUT_FOLDER, context)
        if not folder or not os.path.isdir(folder):
            raise QgsProcessingException(self.tr("Pasta inválida ou não informada."))

        apply_filter = self.parameterAsBoolean(parameters, self.APPLY_FILTER, context)
        min_lat = self.parameterAsDouble(parameters, self.MIN_LAT, context)
        max_lat = self.parameterAsDouble(parameters, self.MAX_LAT, context)
        min_lon = self.parameterAsDouble(parameters, self.MIN_LON, context)
        max_lon = self.parameterAsDouble(parameters, self.MAX_LON, context)

        fields = QgsFields()
        fields.append(QgsField("Arquivo", QVariant.String))
        fields.append(QgsField("Subpasta", QVariant.String))
        fields.append(QgsField("Lat", QVariant.Double))
        fields.append(QgsField("Lon", QVariant.Double))

        crs = QgsCoordinateReferenceSystem("EPSG:4326")
        sink, dest_id = self.parameterAsSink(parameters, self.OUTPUT, context, fields, QgsWkbTypes.Point, crs)
        if sink is None:
            raise QgsProcessingException(self.tr("Não foi possível criar a saída de pontos."))

        # listar .BIN
        bin_files = []
        for root, _, files in os.walk(folder):
            for f in files:
                if f.lower().endswith(".bin"):
                    bin_files.append(os.path.join(root, f))

        if not bin_files:
            feedback.pushInfo(self.tr("Nenhum arquivo .BIN encontrado."))
            return {self.OUTPUT: dest_id}

        feedback.pushInfo(self.tr(f"{len(bin_files)} arquivo(s) .BIN encontrado(s)."))
        total_files = len(bin_files)
        processed_files = 0
        total_points = 0

        for bin_path in bin_files:
            if feedback.isCanceled():
                break
            coords = self._extrair_coordenadas(bin_path, apply_filter, min_lat, max_lat, min_lon, max_lon)
            if coords:
                bf = os.path.basename(bin_path)
                subpasta = os.path.relpath(os.path.dirname(bin_path), folder)
                feats = []
                for lat, lon in coords:
                    feat = QgsFeature(fields)
                    feat.setAttributes([bf, subpasta, float(lat), float(lon)])
                    feat.setGeometry(QgsGeometry.fromPointXY(QgsPointXY(float(lon), float(lat))))
                    feats.append(feat)
                sink.addFeatures(feats)
                total_points += len(feats)

            processed_files += 1
            feedback.setProgress(int(100 * processed_files / total_files))
            feedback.pushInfo(self.tr(f"Processado: {processed_files}/{total_files} - "
                                      f"{os.path.basename(bin_path)} ({len(coords)} ponto(s))"))

        feedback.pushInfo(self.tr(f"Concluído. Pontos gerados: {total_points}"))
        return {self.OUTPUT: dest_id, "NUM_ARQUIVOS": total_files, "NUM_PONTOS": total_points}

    def _extrair_coordenadas(self, bin_path, apply_filter, min_lat, max_lat, min_lon, max_lon):
        coords = []
        try:
            with open(bin_path, "rb") as f:
                data = f.read()
                for i in range(0, len(data) - 8):
                    try:
                        lat_raw, lon_raw = struct.unpack("ii", data[i:i+8])
                        lat, lon = lat_raw / 1e7, lon_raw / 1e7
                        if (not apply_filter) or (min_lat <= lat <= max_lat and min_lon <= lon <= max_lon):
                            coords.append((lat, lon))
                    except Exception:
                        continue
        except Exception:
            pass
        return coords
