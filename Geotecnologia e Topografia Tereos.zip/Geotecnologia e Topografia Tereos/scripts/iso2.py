"""
Model exported as python.
Name : PRO1200 - Gerar Coverages
Group : Desenvolvimento Tecnico
With QGIS : 33410
"""

from qgis.core import QgsProcessing
from qgis.core import QgsProcessingAlgorithm
from qgis.core import QgsProcessingMultiStepFeedback
from qgis.core import QgsProcessingParameterMultipleLayers
from qgis.core import QgsProcessingParameterFeatureSink
from qgis.core import QgsCoordinateReferenceSystem
import processing


class Pro1200GerarCoverages(QgsProcessingAlgorithm):

    def initAlgorithm(self, config=None):
        self.addParameter(QgsProcessingParameterMultipleLayers('camadas_de_pontos', 'Camadas de Pontos', layerType=QgsProcessing.TypeMapLayer, defaultValue=None))
        self.addParameter(QgsProcessingParameterFeatureSink('Pos_aplicacao_pro1200', 'Pos_Aplicacao_PRO1200', type=QgsProcessing.TypeVectorAnyGeometry, createByDefault=True, defaultValue=None))

    def processAlgorithm(self, parameters, context, model_feedback):
        # Use a multi-step feedback, so that individual child algorithm progress reports are adjusted for the
        # overall progress through the model
        feedback = QgsProcessingMultiStepFeedback(4, model_feedback)
        results = {}
        outputs = {}

        # Mesclar Pontos
        alg_params = {
            'CRS': QgsCoordinateReferenceSystem('EPSG:31982'),
            'LAYERS': parameters['camadas_de_pontos'],
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['MesclarPontos'] = processing.run('native:mergevectorlayers', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(1)
        if feedback.isCanceled():
            return {}

        # Voronoi polygons
        alg_params = {
            'BUFFER': 0,
            'COPY_ATTRIBUTES': True,
            'INPUT': outputs['MesclarPontos']['OUTPUT'],
            'TOLERANCE': 0,
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['VoronoiPolygons'] = processing.run('native:voronoipolygons', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(2)
        if feedback.isCanceled():
            return {}

        # Calculadora de campo
        alg_params = {
            'FIELD_LENGTH': 2,
            'FIELD_NAME': 'AREA',
            'FIELD_PRECISION': 2,
            'FIELD_TYPE': 0,  # Decimal (double)
            'FORMULA': '$area',
            'INPUT': outputs['VoronoiPolygons']['OUTPUT'],
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['CalculadoraDeCampo'] = processing.run('native:fieldcalculator', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(3)
        if feedback.isCanceled():
            return {}

        # Extrair por expressão
        alg_params = {
            'EXPRESSION': 'AREA<20',
            'INPUT': outputs['CalculadoraDeCampo']['OUTPUT'],
            'OUTPUT': parameters['Pos_aplicacao_pro1200']
        }
        outputs['ExtrairPorExpresso'] = processing.run('native:extractbyexpression', alg_params, context=context, feedback=feedback, is_child_algorithm=True)
        results['Pos_aplicacao_pro1200'] = outputs['ExtrairPorExpresso']['OUTPUT']
        return results

    def name(self):
        return 'PRO1200 - Gerar Coverages'

    def displayName(self):
        return 'PRO1200 - Gerar Coverages'

    def group(self):
        return 'Processamento de Dados'

    def groupId(self):
        return 'processamento_de_dados'

    def createInstance(self):
        return Pro1200GerarCoverages()
