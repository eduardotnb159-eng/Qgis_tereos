# -*- coding: utf-8 -*-
"""
Algoritmo: Calcular Raio de Distância por Rotas (bloco_plantio x bloco_muda)
Descrição:
- Lê malha de estradas (linhas) e camada de blocos (polígonos; campo do bloco)
- Lê 'plano_plantio' (CSV ou tabela) com colunas 'bloco_plantio' e 'bloco_muda'
- Para cada par, calcula a menor distância pela rede (shortest path) entre os centroides dos blocos
- Fallback automático de algoritmos:
    1) qgis:shortestpathlayertolayer
    2) native:shortestpathlayertolayer
    3) qgis:shortestpathpointtopoint
    4) native:shortestpathpointtopoint
- Converte saída do processing para QgsVectorLayer mesmo se vier como string (id/uri)
- Saídas:
    - Tabela (NoGeometry): bloco_plantio, bloco_muda, raio_muda (m), status
    - (Opcional) Camada de linhas com as rotas
"""

import csv
import processing

from qgis.PyQt.QtCore import QCoreApplication, QVariant
from qgis.core import (
    QgsApplication,
    QgsCoordinateTransform,
    QgsFeature, QgsField, QgsFields, QgsGeometry, QgsPointXY, QgsProject,
    QgsProcessing, QgsProcessingAlgorithm, QgsProcessingException,
    QgsProcessingParameterVectorLayer, QgsProcessingParameterField,
    QgsProcessingParameterVectorDestination, QgsProcessingParameterFile,
    QgsProcessingParameterString, QgsProcessingParameterNumber,
    QgsProcessingParameterFeatureSink, QgsVectorLayer, QgsWkbTypes,
    QgsProcessingUtils
)


class RaioMudaPorRotas(QgsProcessingAlgorithm):
    # Parâmetros
    P_ROADS = "ROADS"
    P_BLOCKS = "BLOCKS"
    P_BLOCK_FIELD = "BLOCK_FIELD"
    P_PLAN = "PLAN"                 # CSV (opcional)
    P_PLAN_LAYER = "PLAN_LAYER"     # tabela carregada (opcional)
    P_PLAN_PLANTIO = "PLAN_PLANTIO_FIELD"
    P_PLAN_MUDA = "PLAN_MUDA_FIELD"
    P_SNAP_TOL = "SNAP_TOL"
    P_OUT_TABLE = "OUT_TABLE"
    P_OUT_ROUTES = "OUT_ROUTES"

    def tr(self, text):
        return QCoreApplication.translate("RaioMudaPorRotas", text)

    def createInstance(self):
        return RaioMudaPorRotas()

    def name(self):
        return "calcular_raio_muda_por_rotas"

    def displayName(self):
        return self.tr("Calcular Raio de Distância por Rotas (bloco_plantio x bloco_muda)")

    def group(self):
        return self.tr("Processamento de Dados")

    def groupId(self):
        return "processamento_de_dados"

    def shortHelpString(self):
        return self.tr(
            "Calcula a distância mínima pela rede de estradas entre os blocos definidos "
            "na planilha (bloco_plantio, bloco_muda). Gera tabela (m) e rotas (opcional)."
        )

    def initAlgorithm(self, config=None):
        self.addParameter(
            QgsProcessingParameterVectorLayer(
                self.P_ROADS, self.tr("Malha de estradas (linhas)"),
                [QgsProcessing.TypeVectorLine]
            )
        )
        self.addParameter(
            QgsProcessingParameterVectorLayer(
                self.P_BLOCKS, self.tr("Shape_geral (polígonos com os blocos)"),
                [QgsProcessing.TypeVectorPolygon]
            )
        )
        self.addParameter(
            QgsProcessingParameterField(
                self.P_BLOCK_FIELD, self.tr("Campo do bloco na camada Shape_geral"),
                parentLayerParameterName=self.P_BLOCKS
            )
        )
        self.addParameter(
            QgsProcessingParameterFile(
                self.P_PLAN, self.tr("Planilha 'plano_plantio' (CSV; opcional se usar tabela)"),
                behavior=QgsProcessingParameterFile.File, optional=True, fileFilter="CSV (*.csv)"
            )
        )
        self.addParameter(
            QgsProcessingParameterVectorLayer(
                self.P_PLAN_LAYER, self.tr("OU selecione a tabela 'plano_plantio' já carregada"),
                [QgsProcessing.TypeVector], optional=True
            )
        )
        self.addParameter(
            QgsProcessingParameterString(
                self.P_PLAN_PLANTIO, self.tr("Campo 'bloco_plantio'"), defaultValue="bloco_plantio"
            )
        )
        self.addParameter(
            QgsProcessingParameterString(
                self.P_PLAN_MUDA, self.tr("Campo 'bloco_muda'"), defaultValue="bloco_muda"
            )
        )
        self.addParameter(
            QgsProcessingParameterNumber(
                self.P_SNAP_TOL, self.tr("Tolerância de snap aos eixos (m)"),
                type=QgsProcessingParameterNumber.Double, defaultValue=20.0, minValue=0.0
            )
        )
        self.addParameter(
            QgsProcessingParameterVectorDestination(
                self.P_OUT_TABLE, self.tr("Saída: Tabela de raios"),
                type=QgsProcessing.TypeVector  # NoGeometry
            )
        )
        self.addParameter(
            QgsProcessingParameterFeatureSink(
                self.P_OUT_ROUTES, self.tr("Saída opcional: Rotas calculadas (linhas)"),
                QgsWkbTypes.LineString, optional=True
            )
        )

    # ---------------- utils ----------------
    def _read_plan_pairs(self, params, context, feedback):
        csv_path = self.parameterAsFile(params, self.P_PLAN, context)
        plan_layer = self.parameterAsVectorLayer(params, self.P_PLAN_LAYER, context)
        f_plantio = self.parameterAsString(params, self.P_PLAN_PLANTIO, context)
        f_muda = self.parameterAsString(params, self.P_PLAN_MUDA, context)

        pairs = []

        def _norm(v):
            v = (v or "").strip()
            return None if (v == "" or v == "-") else v

        if csv_path:
            with open(csv_path, "r", newline="", encoding="utf-8-sig") as f:
                sample = f.read(1024)
                delim = ";" if sample.count(";") > sample.count(",") else ","
                f.seek(0)
                reader = csv.DictReader(f, delimiter=delim)
                for r in reader:
                    bp = _norm(r.get(f_plantio))
                    bm = _norm(r.get(f_muda))
                    if bp and bm:
                        pairs.append((bp, bm))
        elif plan_layer:
            names = plan_layer.fields().names()
            if f_plantio not in names or f_muda not in names:
                raise QgsProcessingException(
                    f"Campos da planilha não encontrados: '{f_plantio}', '{f_muda}'."
                )
            for feat in plan_layer.getFeatures():
                bp = _norm(str(feat[f_plantio]) if feat[f_plantio] is not None else "")
                bm = _norm(str(feat[f_muda]) if feat[f_muda] is not None else "")
                if bp and bm:
                    pairs.append((bp, bm))
        else:
            raise QgsProcessingException("Informe o CSV OU uma tabela carregada para 'plano_plantio'.")

        if not pairs:
            raise QgsProcessingException("Nenhum par válido (bloco_plantio, bloco_muda) encontrado.")
        return pairs

    def _centroid_by_code(self, blocks_vl, block_field, codes_needed):
        idx = {}
        names = blocks_vl.fields().names()
        if block_field not in names:
            raise QgsProcessingException(f"Campo '{block_field}' não encontrado em Shape_geral.")
        for feat in blocks_vl.getFeatures():
            code = str(feat[block_field]).strip()
            if code in codes_needed:
                geom = feat.geometry()
                if not geom or geom.isEmpty():
                    continue
                c = geom.centroid().asPoint()
                idx[code] = QgsPointXY(c)
        return idx

    def _make_point_mem_layer(self, crs):
        vl = QgsVectorLayer(f"Point?crs={crs.authid()}", "tmp_points", "memory")
        pr = vl.dataProvider()
        pr.addAttributes([QgsField("id", QVariant.String)])
        vl.updateFields()
        return vl

    def _reset_point_layer(self, vl, pid, point_xy):
        ids = vl.allFeatureIds()
        if ids:
            vl.dataProvider().deleteFeatures(list(ids))
        vl.startEditing()
        f = QgsFeature(vl.fields())
        f.setAttributes([pid])
        f.setGeometry(QgsGeometry.fromPointXY(point_xy))
        vl.addFeature(f)
        vl.commitChanges()
        vl.updateExtents()

    # --- converter saída do processing para camada válida (layer ou id/uri) ---
    def _to_layer(self, obj, context):
        # já é layer?
        if isinstance(obj, QgsVectorLayer):
            return obj
        # id/expr mapeável?
        if isinstance(obj, str):
            lyr = QgsProcessingUtils.mapLayerFromString(obj, context)
            if isinstance(lyr, QgsVectorLayer) and lyr.isValid():
                return lyr
            # id direto no projeto?
            lyr = QgsProject.instance().mapLayer(obj)
            if isinstance(lyr, QgsVectorLayer) and lyr.isValid():
                return lyr
            # tentar abrir como caminho/URI
            lyr = QgsVectorLayer(obj, "rota_tmp", "ogr")
            if lyr is not None and lyr.isValid():
                return lyr
        raise Exception("Não foi possível resolver a camada de saída do algoritmo de rota.")

    # --------- roteamento tolerante (fallback) ---------
    def _available_algo(self, algo_ids):
        reg = QgsApplication.processingRegistry()
        for a in algo_ids:
            if reg.algorithmById(a):
                return a
        return None

    def _run_shortest_path(self, roads_vl, start_vl, end_vl, snap_tol, context, feedback):
        """
        Tenta layer-to-layer; se indisponível, cai para point-to-point.
        Retorna (QgsVectorLayer path_layer, used_algo_id).
        """
        # 1) layer-to-layer (preferido)
        algo = self._available_algo([
            "qgis:shortestpathlayertolayer",
            "native:shortestpathlayertolayer"
        ])
        if algo:
            res = processing.run(
                algo,
                {
                    "INPUT": roads_vl,
                    "STRATEGY": 0,
                    "DIRECTION_FIELD": None,
                    "SPEED_FIELD": None,
                    "DEFAULT_DIRECTION": 2,
                    "TOLERANCE": snap_tol,
                    "START_POINTS": start_vl,
                    "END_POINTS": end_vl,
                    "OUTPUT": "TEMPORARY_OUTPUT"
                },
                context=context, feedback=feedback, is_child_algorithm=True
            )
            return self._to_layer(res["OUTPUT"], context), algo

        # 2) point-to-point (fallback)
        sp = next(start_vl.getFeatures(), None)
        ep = next(end_vl.getFeatures(), None)
        if not sp or not ep:
            raise Exception("Camadas START/END vazias.")

        spt = sp.geometry().asPoint()
        ept = ep.geometry().asPoint()

        algo = self._available_algo([
            "qgis:shortestpathpointtopoint",
            "native:shortestpathpointtopoint"
        ])
        if algo:
            res = processing.run(
                algo,
                {
                    "INPUT": roads_vl,
                    "STRATEGY": 0,
                    "DIRECTION_FIELD": None,
                    "SPEED_FIELD": None,
                    "DEFAULT_DIRECTION": 2,
                    "TOLERANCE": snap_tol,
                    "START_POINT": f"{spt.x()},{spt.y()}",
                    "END_POINT": f"{ept.x()},{ept.y()}",
                    "OUTPUT": "TEMPORARY_OUTPUT"
                },
                context=context, feedback=feedback, is_child_algorithm=True
            )
            return self._to_layer(res["OUTPUT"], context), algo

        raise Exception("Nenhum algoritmo de menor caminho disponível (ative o plugin 'Network analysis').")

    # ---------------- principal ----------------
    def processAlgorithm(self, params, context, feedback):
        roads_vl = self.parameterAsVectorLayer(params, self.P_ROADS, context)
        blocks_vl = self.parameterAsVectorLayer(params, self.P_BLOCKS, context)
        block_field = self.parameterAsString(params, self.P_BLOCK_FIELD, context)
        snap_tol = self.parameterAsDouble(params, self.P_SNAP_TOL, context)

        if roads_vl is None or blocks_vl is None:
            raise QgsProcessingException("Selecione as camadas de estradas e de blocos.")

        # Ler pares válidos
        pairs = self._read_plan_pairs(params, context, feedback)
        needed = set([p for p, _ in pairs] + [m for _, m in pairs])

        # Indexar centroides
        cdict = self._centroid_by_code(blocks_vl, block_field, needed)

        # Avisar ausentes (não bloqueia)
        missing = [code for code in needed if code not in cdict]
        if missing:
            feedback.pushWarning("Blocos não encontrados em Shape_geral: " + ", ".join(missing))

        # Tabela de saída (NoGeometry)
        out_fields = QgsFields()
        out_fields.append(QgsField("bloco_plantio", QVariant.String))
        out_fields.append(QgsField("bloco_muda", QVariant.String))
        out_fields.append(QgsField("raio_muda", QVariant.Double))
        out_fields.append(QgsField("status",   QVariant.String))
        writer, out_id = self.parameterAsSink(
            params, self.P_OUT_TABLE, context, out_fields, QgsWkbTypes.NoGeometry, roads_vl.sourceCrs()
        )
        if writer is None:
            raise QgsProcessingException("Não foi possível criar a tabela de saída.")

        # Rotas (opcional) — garantir 'route_fields' acessível no loop
        route_sink = None
        route_dest_id = None
        route_fields = None
        if self.P_OUT_ROUTES in params and params[self.P_OUT_ROUTES] is not None:
            route_fields = QgsFields()
            route_fields.append(QgsField("bloco_plantio", QVariant.String))
            route_fields.append(QgsField("bloco_muda", QVariant.String))
            route_fields.append(QgsField("dist_m", QVariant.Double))
            route_sink, route_dest_id = self.parameterAsSink(
                params, self.P_OUT_ROUTES, context, route_fields,
                QgsWkbTypes.LineString, roads_vl.sourceCrs()
            )

        # Transformação: centroides (CRS blocos) -> CRS estradas
        tr_ctx = QgsProject.instance().transformContext()
        ct = QgsCoordinateTransform(blocks_vl.sourceCrs(), roads_vl.sourceCrs(), tr_ctx)

        # Camadas de ponto persistentes
        start_vl = self._make_point_mem_layer(roads_vl.sourceCrs())
        end_vl   = self._make_point_mem_layer(roads_vl.sourceCrs())

        # Loop
        total = len(pairs)
        for i, (bp, bm) in enumerate(pairs, start=1):
            if feedback.isCanceled():
                break
            feedback.setProgress(int(100 * i / total))

            # Verifica centroides
            if bp not in cdict or bm not in cdict:
                f = QgsFeature(out_fields)
                f.setAttributes([bp, bm, None, "bloco_ausente"])
                writer.addFeature(f)
                feedback.pushWarning(f"Par ignorado (bloco ausente/sem geometria): {bp} -> {bm}")
                continue

            # Transformar p/ CRS das estradas
            try:
                p_start = ct.transform(cdict[bp])
                p_end = ct.transform(cdict[bm])
            except Exception as e:
                f = QgsFeature(out_fields)
                f.setAttributes([bp, bm, None, "falha_transform"])
                writer.addFeature(f)
                feedback.pushWarning(f"Falha transformando coordenadas {bp}->{bm}: {e}")
                continue

            # Reusar camadas de 1 ponto
            self._reset_point_layer(start_vl, bp, p_start)
            self._reset_point_layer(end_vl,   bm, p_end)

            # Menor caminho com fallback
            try:
                path_vl, used_algo = self._run_shortest_path(
                    roads_vl, start_vl, end_vl, snap_tol, context, feedback
                )

                dist_m = 0.0
                has_geom = False
                for pf in path_vl.getFeatures():
                    g = pf.geometry()
                    if g and not g.isEmpty():
                        has_geom = True
                        dist_m += g.length()

                status_msg = "ok" if has_geom else "sem_rota"

                # Tabela
                f = QgsFeature(out_fields)
                f.setAttributes([bp, bm, dist_m if has_geom else None, status_msg])
                writer.addFeature(f)

                # Rotas (opcional)
                if route_sink and has_geom:
                    for pf in path_vl.getFeatures():
                        g = pf.geometry()
                        if g and not g.isEmpty():
                            # usa 'route_fields' (não route_sink.fields())
                            rf = QgsFeature(route_fields)
                            rf.setGeometry(g)
                            rf.setAttributes([bp, bm, dist_m])
                            route_sink.addFeature(rf)

                if not has_geom:
                    feedback.pushWarning(f"Sem rota conectada para {bp} -> {bm} (retornando NULL).")

            except Exception as e:
                f = QgsFeature(out_fields)
                f.setAttributes([bp, bm, None, "falha_algo"])
                writer.addFeature(f)
                feedback.pushWarning(f"Falha no par {bp} -> {bm}: {e}")

        return {
            self.P_OUT_TABLE: out_id,
            self.P_OUT_ROUTES: route_dest_id
        }


def classFactory():
    return RaioMudaPorRotas()
