"""
Model exported as python.
Name : Separar Dados por Bloco
Group : Processamento de Dados
With QGIS : 33410
"""

from qgis.core import QgsProcessing
from qgis.core import QgsProcessingAlgorithm
from qgis.core import QgsProcessingMultiStepFeedback
from qgis.core import QgsProcessingParameterVectorLayer
from qgis.core import QgsProcessingParameterFeatureSource
from qgis.core import QgsProcessingParameterField
from qgis.core import QgsProcessingParameterFile
from qgis.core import QgsProcessingParameterDefinition
import processing


class SepararDadosPorBloco(QgsProcessingAlgorithm):

    def initAlgorithm(self, config=None):
        self.addParameter(QgsProcessingParameterVectorLayer('camada_shape', 'Camada_Shape', defaultValue=None))
        self.addParameter(QgsProcessingParameterFeatureSource('camadas_dados_pos', 'CAMADAS_DADOS_POS', types=[QgsProcessing.TypeVectorPolygon], defaultValue=None))
        self.addParameter(QgsProcessingParameterField('campo_de_taxa', 'CAMPO DE TAXA', type=QgsProcessingParameterField.Any, parentLayerParameterName='camadas_dados_pos', allowMultiple=False, defaultValue=None))
        param = QgsProcessingParameterFile('saida_dados_taxa', 'Saida_Dados_Taxa', behavior=QgsProcessingParameterFile.Folder, fileFilter='Todos os arquivos (*.*)', defaultValue=None)
        param.setFlags(param.flags() | QgsProcessingParameterDefinition.FlagAdvanced)
        self.addParameter(param)

    def processAlgorithm(self, parameters, context, model_feedback):
        # Use a multi-step feedback, so that individual child algorithm progress reports are adjusted for the
        # overall progress through the model
        feedback = QgsProcessingMultiStepFeedback(6, model_feedback)
        results = {}
        outputs = {}

        # Renomear campo
        alg_params = {
            'FIELD': parameters['campo_de_taxa'],
            'INPUT': parameters['camadas_dados_pos'],
            'NEW_NAME': 'Taxa_1',
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['RenomearCampo'] = processing.run('native:renametablefield', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(1)
        if feedback.isCanceled():
            return {}

        # Extrair por localização
        alg_params = {
            'INPUT': outputs['RenomearCampo']['OUTPUT'],
            'INTERSECT': parameters['camada_shape'],
            'PREDICATE': [0,5],  # interseccionam,Sobrepõem
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['ExtrairPorLocalizao'] = processing.run('native:extractbylocation', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(2)
        if feedback.isCanceled():
            return {}

        # Campos de retenção
        alg_params = {
            'FIELDS': ['Taxa_1'],
            'INPUT': outputs['ExtrairPorLocalizao']['OUTPUT'],
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['CamposDeReteno'] = processing.run('native:retainfields', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(3)
        if feedback.isCanceled():
            return {}

        # Associar atributos por localização
        alg_params = {
            'DISCARD_NONMATCHING': False,
            'INPUT': outputs['CamposDeReteno']['OUTPUT'],
            'JOIN': parameters['camada_shape'],
            'JOIN_FIELDS': ['BLOCO'],
            'METHOD': 0,  # Criar feição separada para cada feição correspondente (um-para-muitos)
            'PREDICATE': [0,4],  # interseccionam,Sobrepõem
            'PREFIX': '',
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['AssociarAtributosPorLocalizao'] = processing.run('native:joinattributesbylocation', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(4)
        if feedback.isCanceled():
            return {}

        # Editar os campos de Taxa em Numeros
        alg_params = {
            'FIELDS_MAPPING': [{'alias': '','comment': '','expression': '"Taxa_1"','length': 254,'name': 'Taxa_1','precision': 0,'sub_type': 0,'type': 2,'type_name': 'integer'},{'alias': '','comment': '','expression': '"BLOCO"','length': 11,'name': 'BLOCO','precision': 0,'sub_type': 0,'type': 10,'type_name': 'text'}],
            'INPUT': outputs['AssociarAtributosPorLocalizao']['OUTPUT'],
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['EditarOsCamposDeTaxaEmNumeros'] = processing.run('native:refactorfields', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(5)
        if feedback.isCanceled():
            return {}

        # Dividir uma camada vetorial
        alg_params = {
            'FIELD': 'BLOCO',
            'FILE_TYPE': 1,  # shp
            'INPUT': outputs['EditarOsCamposDeTaxaEmNumeros']['OUTPUT'],
            'OUTPUT': parameters['saida_dados_taxa'],
            'PREFIX_FIELD': True,
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['DividirUmaCamadaVetorial'] = processing.run('native:splitvectorlayer', alg_params, context=context, feedback=feedback, is_child_algorithm=True)
        return results

    def name(self):
        return 'Separar Dados por Bloco'

    def displayName(self):
        return 'Separar Dados por Bloco'

    def group(self):
        return 'Processamento de Dados'

    def groupId(self):
        return 'processamento_de_dados'

    def createInstance(self):
        return SepararDadosPorBloco()
