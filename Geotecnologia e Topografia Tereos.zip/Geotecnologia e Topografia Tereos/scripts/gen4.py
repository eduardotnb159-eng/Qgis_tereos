# -*- coding: utf-8 -*-
"""
Exportar linhas de subsolagem para estrutura John Deere Gen4 (MasterData.xml + .gjson)

Lógica:
- Entrada: camada de linhas com campos "BLOCO" e "PARTE"
- Parâmetros:
    • Cliente (ex.: SUBSOLAGEM_TESTE)
    • Pasta de saída

- Para cada BLOCO distinto:
    • Cria pasta: <OUT>/<BLOCO>/Gen4/SpatialFiles
    • Gera MasterData.xml dentro de <BLOCO>/Gen4, com:
        - Client (Name = Cliente informado)
        - Farm  (Name = BLOCO)
        - Field (Name = PARTE, um por PARTE distinto no BLOCO)
        - AdaptiveCurve, um por PARTE, referenciando:
            • TaggedEntity = GUID do Field (PARTE)
            • Geometry/FilenameWithExtension = AdaptiveCurve<GUID_CURVA>.gjson
            • Path = ./SpatialFiles/
            • ReferenceLatitude/Longitude = média dos centróides das linhas da PARTE (em WGS84)

- Cada PARTE gera UM arquivo .gjson (MultiLineString) dentro de SpatialFiles,
  contendo TODAS as linhas daquela PARTE, sem atributos.
  As coordenadas são [x, y, 0, 1] e o JSON é:
  {"geometry":{...},"type":"Feature"}
"""

import os
import json
import uuid
from datetime import datetime
from xml.etree.ElementTree import Element, SubElement, ElementTree

from qgis.PyQt.QtCore import QCoreApplication
from qgis.core import (
    QgsProcessing,
    QgsProcessingAlgorithm,
    QgsProcessingParameterFeatureSource,
    QgsProcessingParameterString,
    QgsProcessingParameterFolderDestination,
    QgsProcessingException,
    QgsCoordinateTransform,
    QgsCoordinateReferenceSystem,
    QgsProject,
    QgsWkbTypes,
    QgsGeometry,
)


class ExportGen4Subsolagem(QgsProcessingAlgorithm):

    PARAM_LINES = "LINES"
    PARAM_CLIENT = "CLIENT"
    PARAM_OUTFOLDER = "OUTFOLDER"

    # Namespace fixo para gerar GUIDs determinísticos a partir de nomes
    CLIENT_NAMESPACE = uuid.UUID("11111111-1111-1111-1111-111111111111")

    def tr(self, text):
        return QCoreApplication.translate("ExportGen4", text)

    def createInstance(self):
        return ExportGen4Subsolagem()

    def name(self):
        return "export_gen4"

    def displayName(self):
        return self.tr("Exportação Projeto (Gen4)")

    def group(self):
        return self.tr("Projetos de Linhas")

    def groupId(self):
        return "projeto_de_linhas"

    def shortHelpString(self):
        return self.tr(
            "Exporta linhas com campos BLOCO e PARTE em estrutura John Deere Gen4:\n"
            "- Para cada BLOCO cria <BLOCO>/Gen4/SpatialFiles\n"
            "- Gera MasterData.xml\n"
            "- Gera 1 arquivo .gjson (MultiLineString) por PARTE, no formato do AgroCAD.\n"
            "- Codigo gerado por Eduardo Leoncio - quaisquer problema, entre em contato!"
        )

    def initAlgorithm(self, config=None):
        # Camada de linhas
        self.addParameter(
            QgsProcessingParameterFeatureSource(
                self.PARAM_LINES,
                self.tr("Camada de linhas (com campos BLOCO e PARTE)"),
                [QgsProcessing.TypeVectorLine]
            )
        )

        # Nome do Cliente
        self.addParameter(
            QgsProcessingParameterString(
                self.PARAM_CLIENT,
                self.tr("Nome do Cliente (ex.: PLANTIO_TANABI)")
            )
        )

        # Pasta de saída
        self.addParameter(
            QgsProcessingParameterFolderDestination(
                self.PARAM_OUTFOLDER,
                self.tr("Pasta de saída (onde serão criadas as pastas dos BLOCOs)")
            )
        )

    # ------------------ Funções auxiliares ------------------

    @staticmethod
    def _ensure_dir(path):
        if not os.path.exists(path):
            os.makedirs(path, exist_ok=True)

    @staticmethod
    def _now_utc_iso():
        # Sem microssegundos, com Z no final
        return datetime.utcnow().replace(microsecond=0).isoformat() + "Z"

    def _build_xml_tree(self, client_name, client_guid, farm_name, farm_guid,
                        fields_info, curves_info, feedback):
        """
        Monta a árvore XML (xml.etree.ElementTree.Element) para um BLOCO.
        fields_info: dict {parte_str: field_guid}
        curves_info: lista de dicts:
            {
                'curve_guid': str,
                'name': str,
                'field_guid': str,
                'ref_lat': float,
                'ref_lon': float,
                'filename': str
            }
        """

        import xml.etree.ElementTree as ET
        NS = "urn:schemas-johndeere-com:Setup"
        ET.register_namespace("", NS)
        ET.register_namespace("xsi", "http://www.w3.org/2001/XMLSchema-instance")
        ET.register_namespace("xsd", "http://www.w3.org/2001/XMLSchema")

        root = Element(f"{{{NS}}}SetupFile")

        # SourceApp (mantemos básico)
        source_app = SubElement(root, f"{{{NS}}}SourceApp")
        source_app.set("minor", "0")
        source_app.set("major", "0")
        source_app.set("build", "0")
        source_app.set("revision", "0")
        source_app.set("nameSourceApp", "")
        source_app.set("SourceAppClientId", "")

        # Versões do schema (do exemplo)
        file_schema_version = SubElement(root, f"{{{NS}}}FileSchemaVersion")
        file_schema_version.set("nonProductionCode", "0")

        fscv = SubElement(file_schema_version, f"{{{NS}}}FileSchemaContentVersion")
        fscv.set("major", "2")
        fscv.set("minor", "19")

        uomv = SubElement(file_schema_version, f"{{{NS}}}UnitOfMeasureVersion")
        uomv.set("major", "1")
        uomv.set("minor", "8")

        rsv = SubElement(file_schema_version, f"{{{NS}}}RepresentationSystemVersion")
        rsv.set("major", "3")
        rsv.set("minor", "13")

        # Nó Setup
        setup = SubElement(root, f"{{{NS}}}Setup")

        # Client
        client_el = SubElement(setup, f"{{{NS}}}Client")
        client_el.set("Archived", "false")
        client_el.set("StringGuid", client_guid)
        client_el.set("Name", client_name)

        now_iso = self._now_utc_iso()

        # Farm
        farm_el = SubElement(setup, f"{{{NS}}}Farm")
        farm_el.set("LastModifiedDate", now_iso)
        farm_el.set("Archived", "false")
        farm_el.set("StringGuid", farm_guid)
        farm_el.set("Name", farm_name)
        farm_el.set("Client", client_guid)

        # Fields (um por PARTE)
        for parte_str, field_guid in fields_info.items():
            field_el = SubElement(setup, f"{{{NS}}}Field")
            field_el.set("LastModifiedDate", now_iso)
            field_el.set("Archived", "false")
            field_el.set("StringGuid", field_guid)
            field_el.set("Name", parte_str)

            farm_ref = SubElement(field_el, f"{{{NS}}}Farm")
            farm_ref.text = farm_guid

        # Inputs (vazio)
        inputs_el = SubElement(setup, f"{{{NS}}}Inputs")
        SubElement(inputs_el, f"{{{NS}}}Products")

        # Guidance / Tracks / AdaptiveCurve
        guidance_el = SubElement(setup, f"{{{NS}}}Guidance")
        tracks_el = SubElement(guidance_el, f"{{{NS}}}Tracks")

        for curve in curves_info:
            ac_el = SubElement(tracks_el, f"{{{NS}}}AdaptiveCurve")
            ac_el.set("Archived", "false")
            ac_el.set("StringGuid", curve["curve_guid"])
            ac_el.set("Name", curve["name"])
            ac_el.set("TaggedEntity", curve["field_guid"])

            sig = SubElement(ac_el, f"{{{NS}}}SignalType")
            sig.set("Representation", "dtSignalType")
            sig.set("Value", "dtiSignalTypeUnknown")

            geom_el = SubElement(ac_el, f"{{{NS}}}Geometry")
            fn_el = SubElement(geom_el, f"{{{NS}}}FilenameWithExtension")
            fn_el.text = curve["filename"]
            path_el = SubElement(geom_el, f"{{{NS}}}Path")
            path_el.text = "./SpatialFiles/"

            sp_el = SubElement(ac_el, f"{{{NS}}}SpatialProjection")
            proj_el = SubElement(sp_el, f"{{{NS}}}ProjectionType")
            proj_el.set("Representation", "dtProjectionType")
            proj_el.set("Value", "dtiProjectionDeere")

            elev_el = SubElement(sp_el, f"{{{NS}}}ElevationReferencePoint")
            elev_el.set("Representation", "vrElevation")
            elev_el.set("Value", "0")
            elev_el.set("SourceUnit", "m")

            ref_lat_el = SubElement(ac_el, f"{{{NS}}}ReferenceLatitude")
            ref_lat_el.set("Representation", "vrLatitude")
            ref_lat_el.set("Value", f"{curve['ref_lat']}")
            ref_lat_el.set("SourceUnit", "arcdeg")

            ref_lon_el = SubElement(ac_el, f"{{{NS}}}ReferenceLongitude")
            ref_lon_el.set("Representation", "vrLongitude")
            ref_lon_el.set("Value", f"{curve['ref_lon']}")
            ref_lon_el.set("SourceUnit", "arcdeg")

        # SourceInformation
        src_info = SubElement(setup, f"{{{NS}}}SourceInformation")
        SubElement(src_info, f"{{{NS}}}DisplayName")
        SubElement(src_info, f"{{{NS}}}Version")
        SubElement(src_info, f"{{{NS}}}SourceApplication")

        # CreatedDateTime
        created_el = SubElement(setup, f"{{{NS}}}CreatedDateTime")
        created_el.text = now_iso

        return root

    # ------------------ Execução principal ------------------

    def processAlgorithm(self, parameters, context, feedback):

        source = self.parameterAsSource(parameters, self.PARAM_LINES, context)
        if source is None:
            raise QgsProcessingException(self.tr("Camada de linhas inválida."))

        client_name = self.parameterAsString(parameters, self.PARAM_CLIENT, context)
        out_folder = self.parameterAsString(parameters, self.PARAM_OUTFOLDER, context)

        if not client_name:
            raise QgsProcessingException(self.tr("Informe um nome de Cliente."))

        if not out_folder:
            raise QgsProcessingException(self.tr("Informe a pasta de saída."))

        self._ensure_dir(out_folder)

        fields = source.fields()
        field_names = [f.name() for f in fields]

        if "BLOCO" not in field_names:
            raise QgsProcessingException(self.tr("Campo 'BLOCO' não encontrado na camada."))

        if "PARTE" not in field_names:
            raise QgsProcessingException(self.tr("Campo 'PARTE' não encontrado na camada."))

        idx_bloco = fields.lookupField("BLOCO")
        idx_parte = fields.lookupField("PARTE")

        # Transformação para WGS84
        src_crs = source.sourceCrs()
        wgs84 = QgsCoordinateReferenceSystem("EPSG:4326")
        if src_crs.isValid() and src_crs != wgs84:
            xform = QgsCoordinateTransform(src_crs, wgs84, QgsProject.instance())
        else:
            xform = None

        # Agrupar feições por BLOCO
        blocks = {}  # {bloco_str: [feature, ...]}
        features_list = list(source.getFeatures())

        total = len(features_list)
        if total == 0:
            feedback.pushInfo(self.tr("Nenhuma feição encontrada na camada."))
            return {self.PARAM_OUTFOLDER: out_folder}

        for feat in features_list:
            if feedback.isCanceled():
                break

            bloco_val = feat.attribute(idx_bloco)
            parte_val = feat.attribute(idx_parte)

            bloco_str = str(bloco_val).strip()
            parte_str = str(parte_val).strip()

            if not bloco_str:
                feedback.pushInfo(self.tr(f"Feição {feat.id()} sem BLOCO definido. Ignorando."))
                continue

            if not parte_str:
                parte_str = "01"

            block = blocks.setdefault(bloco_str, [])
            block.append(feat)

        if not blocks:
            feedback.pushInfo(self.tr("Nenhum BLOCO válido encontrado."))
            return {self.PARAM_OUTFOLDER: out_folder}

        # GUID determinístico para o Cliente (baseado no nome)
        client_guid = str(uuid.uuid5(self.CLIENT_NAMESPACE, client_name))

        # Processar cada BLOCO
        for bloco_str, feats in blocks.items():
            if feedback.isCanceled():
                break

            feedback.pushInfo(self.tr(f"▶ Processando BLOCO: {bloco_str} ({len(feats)} linhas)..."))

            # Pasta do BLOCO
            bloco_dir = os.path.join(out_folder, bloco_str)
            gen4_dir = os.path.join(bloco_dir, "Gen4")
            spatial_dir = os.path.join(gen4_dir, "SpatialFiles")

            self._ensure_dir(spatial_dir)

            # GUID determinístico para Farm, baseado em (client_guid, bloco)
            farm_guid = str(uuid.uuid5(uuid.UUID(client_guid), bloco_str))

            # Agrupar geometrias por PARTE (já em WGS84)
            parts_geoms = {}  # {parte_str: [geom_wgs, ...]}

            for feat in feats:
                if feedback.isCanceled():
                    break

                parte_val = feat.attribute(idx_parte)
                parte_str = str(parte_val).strip()
                if not parte_str:
                    parte_str = "01"

                geom = feat.geometry()
                if geom is None or geom.isEmpty():
                    feedback.pushInfo(self.tr(f"Feição {feat.id()} sem geometria. Ignorando."))
                    continue

                geom_wgs = QgsGeometry(geom)
                if xform is not None:
                    try:
                        geom_wgs.transform(xform)
                    except Exception as e:
                        feedback.pushInfo(self.tr(f"Erro ao transformar geometria {feat.id()}: {e}"))
                        continue

                parts_geoms.setdefault(parte_str, []).append(geom_wgs)

            if not parts_geoms:
                feedback.pushInfo(self.tr(f"Nenhuma PARTE válida encontrada no BLOCO {bloco_str}."))
                continue

            # Fields por PARTE + Curvas por PARTE
            fields_info = {}   # {parte_str: field_guid}
            curves_info = []   # lista de dicts

            for parte_str, geoms_list in parts_geoms.items():
                if feedback.isCanceled():
                    break

                if not geoms_list:
                    feedback.pushInfo(self.tr(f"PARTE {parte_str} no BLOCO {bloco_str} sem geometrias. Ignorando."))
                    continue

                # Field GUID determinístico baseado em (farm_guid, parte)
                field_guid = str(uuid.uuid5(uuid.UUID(farm_guid), parte_str))
                fields_info[parte_str] = field_guid

                # GUID da curva
                curve_guid = str(uuid.uuid4())
                filename = f"AdaptiveCurve{curve_guid}.gjson"
                curve_name = f"CURVA_{parte_str}"

                # Construir MultiLineString com TODAS as linhas da PARTE
                multi_coords = []  # [[ [x,y,0,1], ... ], [ ... ], ... ]
                sum_x = 0.0
                sum_y = 0.0
                count_centroids = 0

                for geom_wgs in geoms_list:
                    cent = geom_wgs.centroid()
                    ptc = cent.asPoint()
                    sum_x += ptc.x()
                    sum_y += ptc.y()
                    count_centroids += 1

                    if QgsWkbTypes.isMultiType(geom_wgs.wkbType()):
                        multi = geom_wgs.asMultiPolyline()
                        for line in multi:
                            coords_line = [[p.x(), p.y(), 0, 1] for p in line]
                            if coords_line:
                                multi_coords.append(coords_line)
                    else:
                        line = geom_wgs.asPolyline()
                        coords_line = [[p.x(), p.y(), 0, 1] for p in line]
                        if coords_line:
                            multi_coords.append(coords_line)

                if not multi_coords:
                    feedback.pushInfo(self.tr(f"PARTE {parte_str} no BLOCO {bloco_str} sem coordenadas válidas. Ignorando."))
                    continue

                # Reference latitude/longitude = média dos centróides
                if count_centroids > 0:
                    ref_lon = sum_x / count_centroids
                    ref_lat = sum_y / count_centroids
                else:
                    first_pt = multi_coords[0][0]
                    ref_lon = first_pt[0]
                    ref_lat = first_pt[1]

                geometry_geojson = {
                    "type": "MultiLineString",
                    "coordinates": multi_coords
                }

                # 👉 IGUAL AO AGROCAD: raiz é um Feature simples
                gjson_dict = {
                    "geometry": geometry_geojson,
                    "type": "Feature"
                }

                # Gravar .gjson COMPACTO
                gjson_path = os.path.join(spatial_dir, filename)
                with open(gjson_path, "w", encoding="utf-8") as f:
                    json.dump(
                        gjson_dict,
                        f,
                        ensure_ascii=False,
                        separators=(",", ":")  # tudo junto
                    )

                curves_info.append(
                    {
                        "curve_guid": curve_guid,
                        "name": curve_name,
                        "field_guid": field_guid,
                        "ref_lat": ref_lat,
                        "ref_lon": ref_lon,
                        "filename": filename,
                    }
                )

                feedback.pushInfo(self.tr(
                    f"  • PARTE {parte_str}: {len(geoms_list)} linhas ⇒ {filename} (MultiLineString, [x,y,0,1])"
                ))

            # Construir árvore XML para esse BLOCO
            xml_root = self._build_xml_tree(
                client_name=client_name,
                client_guid=client_guid,
                farm_name=bloco_str,
                farm_guid=farm_guid,
                fields_info=fields_info,
                curves_info=curves_info,
                feedback=feedback,
            )

            master_path = os.path.join(gen4_dir, "MasterData.xml")
            tree = ElementTree(xml_root)
            tree.write(master_path, encoding="utf-8", xml_declaration=True)

            feedback.pushInfo(self.tr(f"  ✓ BLOCO {bloco_str} exportado em: {gen4_dir}"))

        feedback.pushInfo(self.tr("✅ Exportação concluída."))

        return {self.PARAM_OUTFOLDER: out_folder}
