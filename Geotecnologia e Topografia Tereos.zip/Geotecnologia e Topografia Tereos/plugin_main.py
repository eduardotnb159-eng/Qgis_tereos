from qgis.core import QgsApplication
from .provider import Geotecnologia_e_topografia_tereosProvider

class Geotecnologia_e_topografia_tereosPlugin:
    def __init__(self, iface):
        self.iface = iface
        self.provider = None

    def initGui(self):
        self.provider = Geotecnologia_e_topografia_tereosProvider()
        QgsApplication.processingRegistry().addProvider(self.provider)

    def unload(self):
        if self.provider:
            QgsApplication.processingRegistry().removeProvider(self.provider)

def classFactory(iface):
    return Geotecnologia_e_topografia_tereosPlugin(iface)
