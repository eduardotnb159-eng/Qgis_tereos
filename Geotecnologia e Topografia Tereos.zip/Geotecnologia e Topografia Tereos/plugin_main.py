from qgis.core import QgsApplication
from .provider import MeuProvider

class MeuPlugin:
    def __init__(self, iface):
        self.iface = iface
        self.provider = None

    def initGui(self):
        # Adiciona o provider de processamento
        self.provider = MeuProvider()
        QgsApplication.processingRegistry().addProvider(self.provider)

    def unload(self):
        # Remove o provider quando o plugin é desativado
        if self.provider:
            QgsApplication.processingRegistry().removeProvider(self.provider)

def classFactory(iface):
    return MeuPlugin(iface)
