import os, importlib.util, types
from qgis.core import QgsProcessingProvider, QgsProcessingAlgorithm, QgsProcessingModelAlgorithm, QgsApplication, Qgis
from qgis.PyQt.QtGui import QIcon

class ModelAlgorithmWithIcon(QgsProcessingModelAlgorithm):
    def __init__(self, path, icon_path=None):
        super().__init__()
        self._path = path
        self._icon_path = icon_path
        self.fromFile(path)
    def icon(self):
        if self._icon_path and os.path.exists(self._icon_path):
            return QIcon(self._icon_path)
        return QIcon(os.path.join(os.path.dirname(__file__), "icons", "tereos.png"))

class Geotecnologia_e_topografia_tereosProvider(QgsProcessingProvider):
    def __init__(self): super().__init__()
    def loadAlgorithms(self):
        base_dir = os.path.dirname(__file__)
        scripts_dir = os.path.join(base_dir, "scripts")
        models_dir = os.path.join(base_dir, "models")
        icons_dir = os.path.join(base_dir, "icons")
        default_icon = os.path.join(icons_dir, "tereos.png")

        # Scripts .py
        if os.path.exists(scripts_dir):
            for file in os.listdir(scripts_dir):
                if file.endswith(".py"):
                    path_script = os.path.join(scripts_dir, file)
                    nome_base = os.path.splitext(file)[0]
                    try:
                        spec = importlib.util.spec_from_file_location(nome_base, path_script)
                        module = importlib.util.module_from_spec(spec)
                        spec.loader.exec_module(module)
                        for attr_name in dir(module):
                            attr = getattr(module, attr_name)
                            if (
                                isinstance(attr, type)
                                and issubclass(attr, QgsProcessingAlgorithm)
                                and attr is not QgsProcessingAlgorithm
                            ):
                                alg = attr()
                                icon_path = os.path.join(icons_dir, nome_base + ".png")
                                alg.icon = types.MethodType(
                                    (lambda self, p=icon_path, d=default_icon:
                                        QIcon(p) if os.path.exists(p) else QIcon(d)),
                                    alg
                                )
                                self.addAlgorithm(alg)
                    except Exception as e:
                        QgsApplication.messageLog().logMessage(f"Erro importando {file}: {e}", "geotecnologia_e_topografia_tereos", Qgis.Critical)

        # Modelos .model3
        if os.path.exists(models_dir):
            for file in os.listdir(models_dir):
                if file.endswith(".model3"):
                    path_modelo = os.path.join(models_dir, file)
                    nome_base = os.path.splitext(file)[0]
                    icon_path = os.path.join(icons_dir, nome_base + ".png")
                    try:
                        alg = ModelAlgorithmWithIcon(path_modelo, icon_path if os.path.exists(icon_path) else None)
                        self.addAlgorithm(alg)
                    except Exception as e:
                        QgsApplication.messageLog().logMessage(f"Erro carregando modelo {file}: {e}", "geotecnologia_e_topografia_tereos", Qgis.Critical)

    def id(self): return "geotecnologia_e_topografia_tereos"
    def name(self): return "Geotecnologia e Topografia Tereos"
    def longName(self): return "Ferramentas - Geotecnologia e Topografia Tereos"
    def icon(self): return QIcon(os.path.join(os.path.dirname(__file__), "icons", "tereos.png"))
