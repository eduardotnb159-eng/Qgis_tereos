import os
import importlib.util
import types
from qgis.core import (
    QgsProcessingProvider,
    QgsProcessingAlgorithm,
    QgsProcessingModelAlgorithm,
    QgsApplication,
    Qgis
)
from qgis.PyQt.QtGui import QIcon

# Wrapper para modelos com suporte a ícone (.png)
class ModelAlgorithmWithIcon(QgsProcessingModelAlgorithm):
    def __init__(self, path, icon_path=None):
        super().__init__()
        self._path = path
        self._icon_path = icon_path
        self.fromFile(path)

    def icon(self):
        # Ícone por modelo → icons/<nome>.png; fallback tereos.png
        if self._icon_path and os.path.exists(self._icon_path):
            return QIcon(self._icon_path)
        return QIcon(os.path.join(os.path.dirname(__file__), "icons", "tereos.png"))

class MeuProvider(QgsProcessingProvider):
    def loadAlgorithms(self):
        base_dir = os.path.dirname(__file__)
        scripts_dir = os.path.join(base_dir, "scripts")
        models_dir = os.path.join(base_dir, "models")
        icons_dir = os.path.join(base_dir, "icons")
        default_icon = os.path.join(icons_dir, "tereos.png")

        # 1) Carregar algoritmos Python (.py)
        if os.path.exists(scripts_dir):
            for file in os.listdir(scripts_dir):
                if not file.endswith(".py"):
                    continue
                path_script = os.path.join(scripts_dir, file)
                nome_base = os.path.splitext(file)[0]
                try:
                    spec = importlib.util.spec_from_file_location(nome_base, path_script)
                    module = importlib.util.module_from_spec(spec)
                    spec.loader.exec_module(module)
                except Exception as e:
                    QgsApplication.messageLog().logMessage(
                        f"[Scripts] Erro importando {file}: {e}", "geotecnologia_e_topografia_tereos", Qgis.Critical
                    )
                    continue
                for attr_name in dir(module):
                    attr = getattr(module, attr_name)
                    if (
                        isinstance(attr, type)
                        and issubclass(attr, QgsProcessingAlgorithm)
                        and attr is not QgsProcessingAlgorithm
                    ):
                        try:
                            alg = attr()
                        except Exception as e:
                            QgsApplication.messageLog().logMessage(
                                f"[Scripts] Erro instanciando {attr_name} ({file}): {e}",
                                "geotecnologia_e_topografia_tereos", Qgis.Critical
                            )
                            continue
                        icon_path = os.path.join(icons_dir, nome_base + ".png")
                        alg.icon = types.MethodType(
                            (lambda self, p=icon_path, d=default_icon:
                                QIcon(p) if p and os.path.exists(p) else QIcon(d)),
                            alg
                        )
                        self.addAlgorithm(alg)

        # 2) Carregar modelos (.model3)
        if os.path.exists(models_dir):
            for file in os.listdir(models_dir):
                if not file.endswith(".model3"):
                    continue
                path_modelo = os.path.join(models_dir, file)
                nome_base = os.path.splitext(file)[0]
                icon_path = os.path.join(icons_dir, nome_base + ".png")
                try:
                    alg = ModelAlgorithmWithIcon(path_modelo, icon_path if os.path.exists(icon_path) else None)
                    self.addAlgorithm(alg)
                except Exception as e:
                    QgsApplication.messageLog().logMessage(
                        f"[Modelos] Erro carregando {file}: {e}", "geotecnologia_e_topografia_tereos", Qgis.Critical
                    )

    def id(self):
        return "geotecnologia_e_topografia_tereos"

    def name(self):
        return "Geotecnologia e Topografia Tereos"

    def longName(self):
        return "Ferramentas - Geotecnologia e Topografia Tereos"

    def icon(self):
        return QIcon(os.path.join(os.path.dirname(__file__), "icons", "tereos.png"))
